
<p class="title">Mercato libero - fase 4 (risultati) </p>
  <table width="100%" border="1" cellpadding="5" cellspacing="0" class="default">
  <tr> 
      <td width="50%" class="default"><p>Risultati:</p>
      <p>
	  
	  <?php
	  
	if($oramercato[2]!="")
	  	$risultati=risultati_asta($weekmercato,$nometeam);
	else 
		$risultati=giocatori_chiamati($weekmercato,$nometeam);
	while (list($chiave,$valore)=each($risultati))
		echo $chiave." :".$valore."<br>";
	  
	  ?>
	  
	  </p></td>
  </tr>
</table>