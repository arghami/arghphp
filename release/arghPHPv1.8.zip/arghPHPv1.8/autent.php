<?php

$user=$_POST[user];
$pass=$_POST[pass];  //si prende le variabili passate dalla POST del form di login

$valid=0;
$handle=fopen("users/users.us","r");

while(!$valid&&!feof($handle)){			//si interrompe se viene trovato l'user oppure alla fine del file
	$dati=explode("\t",fgets($handle));
	if($dati[0]==$user)
	    $valid=1;
	}
fclose($handle);

if (!$valid)  {		//se l'utente non � stato trovato
	echo "Attenzione, nome utente o password non validi.<br>";
	echo "<a href=\"javascript:history.back();\">Indietro</a>";
	die();
}

	else{
	$id=$dati[1];
	$password=$dati[2];

	if (crypt($pass,"key")!=$password)	//se la password non corrisponde
		{
		echo "Attenzione, nome utente o password non validi.<br>";
		echo "<a href=\"javascript:history.back();\">Indietro</a>";
		die();
		}
	else
	{
	session_start();
	$_SESSION["user"]=$user;
	$_SESSION["id"]=$id;
	
	//prende l'ultimo accesso e lo aggiorna per la volta successiva
	$_SESSION["lastlog"]=file_get_contents("users/lastlog.$id");
	$ultimoaccesso=time();
	$fid=fopen("users/lastlog.$id",'w');
	fwrite($fid,$ultimoaccesso);
	fclose($fid);
	
	echo "<head>
<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">
</head>";
     }
}


?>

