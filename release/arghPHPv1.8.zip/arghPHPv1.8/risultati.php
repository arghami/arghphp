<html>
<head>
<title>Risultati </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="style.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<?php
$resultFileName=glob("result/*Risultati".$_GET["giornata"].".tab");
if (@ !$file=fopen($resultFileName[0],'r'))
	die ("<p class=\"default\">Risultati non ancora disponibili. <a href=\"index.php\"> Torna alla homepage</a></p>");
include("variabili.php");
$ruoli=array(1=>"P","D","C","A");
$fontcolor=array(1=>"#999900","#009900","#990000","#000099","#000000");
?>
<p class="title">Risultati 
  <?php scorri($file,2); $rigo=explode("\t",fgets($file)); echo $rigo[2];?>
  giornata </p>
<p class="default"><a href="index.php">Torna alla homepage</a></p>
<table bordercolor="#000000" border="1" cellpadding="5"><tr><td>
      <table width="900" align="center" cellpadding=0 cellspacing=3>
        <tr>
          <td width="20">&nbsp;</td>
          <td width="30">&nbsp;</td>
          <td width="190">&nbsp;</td>
          <td width="70">&nbsp;</td>
          <td width="70">&nbsp;</td>
          <td width="70">&nbsp;</td>
          <td width="20">&nbsp;</td>
          <td width="30">&nbsp;</td>
          <td width="190">&nbsp;</td>
          <td width="70">&nbsp;</td>
          <td width="70">&nbsp;</td>
          <td width="70">&nbsp;</td>
        </tr>
        <?php

while (!feof($file)){
	echo "<tr class=\"mini\">";
	$rigo=explode("\t",fgets($file));
	if(array_search($rigo[2],$nometeam)){
		for($i=0;$i<count($rigo);$i++){
			echo "<td class=\"big\"><i>";
			if($rigo[$i]) echo $rigo[$i]; else echo "&nbsp;";
			echo "</i></td>";
			}
	}
	
	elseif (substr($rigo[2],0,10)=="Campionato")
		for($i=0;$i<count($rigo);$i++)
			echo "<td>&nbsp;</td>";
	
	elseif (substr($rigo[4],0,5)=="Parzi" || substr($rigo[4],0,5)=="Total")
		for($i=0;$i<count($rigo);$i++){
			echo "<td";
			if ($i%6==5)
				echo " bgcolor=\"#CCCC66\"><b>$rigo[$i]</b></td>";
			else echo ">$rigo[$i]</td>";
		}
			
	elseif (array_search(substr($rigo[1],0,1),$ruoli) || array_search(substr($rigo[7],0,1),$ruoli))
		for($j=0;$j<2;$j++){
			$opt[2]=$opt[1]=array_search(substr($rigo[1+6*$j],0,1),$ruoli);
			echo "<td>&nbsp</td>";
			if ($rigo[3+6*$j]<6) $opt[3]=3; else $opt[3]=2;
			$opt[4]=5;
			if ($rigo[5+6*$j]<6) $opt[5]=3; else $opt[5]=2;
			for($i=1;$i<count($rigo)/2;$i++)
			echo "<td><font color=\"{$fontcolor[$opt[$i]]}\"><b>{$rigo[$i+6*$j]}</b></font></td>";
		}
	
	elseif ($rigo[4]=="Gol")
		for($i=0;$i<count($rigo);$i++){
			echo "<td";
			if ($i==5 || $i==11) echo " bgcolor=\"#00FF00\" class=\"enorme\"";
			echo ">$rigo[$i]</td>";
		}
	
	else
		for($i=0;$i<count($rigo);$i++)
			echo "<td>$rigo[$i]</td>";
				
	echo "</tr>
	";

}
fclose($file);
?>
      </table>
</td></tr></table>
</body>
</html>
