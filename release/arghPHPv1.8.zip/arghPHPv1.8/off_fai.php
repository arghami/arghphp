<?php
if ($user=="webmaster")
	echo "Ciao, webmaster!";
else

{
	$weekday=date("w");
	if (!$weekday) $weekday=7;
	$hour=date("G");
	for ($fase=1; $fase<4; $fase++) {
		if (!isset($oramercato[$fase]) || $weekday>$giornomercato[$fase] || ($weekday==$giornomercato[$fase] && $hour>=$oramercato[$fase]))
			continue;
		else break;
	}
	$file=fopen("mercato.txt",'r');
	$weekmercato=0; $i=1;
	while  (!feof($file)) {
		$temp=explode("\t",fgets($file));
		if (time()>strtotime($temp[0]) && time()<strtotime($temp[1])) {
			$weekmercato=$i; break;
		}
		$i++;
	}
$nomefilesvinc=glob("*Risultati*Liberi*");
if (!$weekmercato){
	echo "<p class=\"default\">Questa settimana non si fa mercato. Le settimane in cui il mercato � aperto sono:<br><br>";
	echo str_replace(array("\n","\t","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"),array("<br>"," - ","Gen","Feb","Mar","Apr","Mag","Giu","Lug","Ago","Set","Ott","Nov","Dic"),file_get_contents("mercato.txt"));
}
else include("off_fai$fase.php");
}
?>