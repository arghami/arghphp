<div align="center">
  <p><img src="stat.jpg" width="425" height="54"></p>
</div>

<p class="default">&nbsp;</p>
<table width="300" border="0">
  <tr>
    <td class="default" background="bar2.jpg"><b>Classifica marcatori</b></td>
  </tr>
</table>

<p class="mini">E' una cosa diversa rispetto alla reale classifica 
  marcatori della serie A, e tiene conto dei gol effettivamente segnati dalle 
  squadre del nostro fantacampionato. La regola &egrave; questa: si considerano 
  le fantamedie dei propri giocatori, e si d&agrave; un gol a quello che ha la 
  fantamedia pi&ugrave; alta, e gli si tolgono 3 punti. Si procede cos&igrave; 
  finquando non sono stati assegnati tutti i gol segnati dalla fantasquadra. Questo 
  sistema far&agrave; &quot;segnare&quot; parecchi gol ai giocatori che hanno 
  una media alta, anche se alla fine quelli che segnano ci sono sempre. In caso 
  di parit&agrave; di fantamedie tra due giocatori, il sistema prende il primo 
  che compare nella formazione, favorendo difensori e centrocampisti. I portieri 
  sono esclusi da questo calcolo. La classifica mostra i primi 25 marcatori, mentre 
  per i marcatori di ogni singola giornata potete consultare la sezione del calendario.</p>
<p class="default">

  <?php
$incontri=estrai_giornate($filecalendario,$nometeam);

for ($i=1;$i<=count($incontri);$i++)
	for ($j=1;$j<=$num_squadre;$j++){
		$goleador=marcatori($nometeam[$j],$incontri[$i][1]);
		for($k=0;$k<count($goleador);$k++)
			if (@ array_key_exists($goleador[$k],$marcatori))
				$marcatori[$goleador[$k]]++;
			else
				$marcatori[$goleador[$k]]=1;
	}
arsort($marcatori);
$count=0;
while ((list($chiave, $valore) = each($marcatori)) && $count<25){
    echo "<b>$valore</b> ".squadre_appartenenza($chiave,$nometeam,$filerose)."<br>";
	$count++;
}
?>
</p>
<table width="300" border="0">
  <tr> 
    <td class="default" background="bar2.jpg"><b>Statistiche sulle squadre</b></td>
  </tr>
</table>
<p class="default"><b>Il quadro generale</b></p>
<table border="1" cellpadding="0" cellspacing="0">
  <?php

function vinciperdi ($a,$b){
	$a=trim($a);
	$b=trim($b);
	if ($a<$b){
		$vett[0]='s';
		$vett[1]='v';
	}
	else if ($a>$b) {
		$vett[0]='v';
		$vett[1]='s';
	}
	else
		$vett[0]=$vett[1]='p';
return $vett;
}

function conta ($arr,$char1,$char2) {       // conta quante ricorrenze consecutive di char1 e char2 ci sono nel vettore $arr, al massimo.

$cumulo[0]=0;
	for ($i=1;$i<=count($arr);$i++)
		if ($arr[$i]==$char1 || $arr[$i]==$char2)
			$cumulo[$i]=$cumulo[$i-1]+1;
		else
			$cumulo[$i]=0;

@ $last=array_search($cumulo,max($cumulo));
$first=$last-max($cumulo)+1;
return array($first,$last);

}

foreach($nometeam as $value)
	$ris[$value][0]=0;

for ($i=1;$i<$_SESSION["gior"];$i++){
	$resultFileName=glob("result/*Risultati".$i.".tab");
	if(@ $file=fopen($resultFileName[0],"r"))			//se � disponibile il file coi risultati
		while(!feof($file)){
			$array=explode("\t",fgets($file));
			if(array_search($array[2],$nometeam))				//scorre il file, quando trova nomi di squadre li prende e li plotta
				list($tmp1,$tmp2)=array($array[2],$array[8]);
			if($array[4]=="Gol")	//quando trova i gol li plotta
				list($ris[$tmp1][],$ris[$tmp2][])=vinciperdi($array[5],$array[11]);	
		}
}

foreach($nometeam as $value)
	unset($ris[$value][0]);
  
for ($i=1;$i<=$num_squadre;$i++){
	echo "<tr class=\"mini\">";
	echo "<td>$nometeam[$i]</td>";
	for ($j=1;$j<=count($ris[$nometeam[1]]);$j++){
		switch ($ris[$nometeam[$i]][$j]){
			case 'v': $color="#00FF00"; break;
			case 'p': $color="#FFFF00"; break;
			case 's': $color="#FF9966"; break;
		}
		echo "<td bgcolor=\"$color\">".$ris[$nometeam[$i]][$j]."</td>";
	}
	echo "</tr>";
}
?>
</table>

<p class="default"> 
  <?php

for ($i=1;$i<=$num_squadre;$i++){

	list($first,$last)=conta($ris[$nometeam[$i]],'v','v');
	$vitt[$nometeam[$i]]=$last-$first+1;
	list($first,$last)=conta($ris[$nometeam[$i]],'p','p');
	$pari[$nometeam[$i]]=$last-$first+1;
	list($first,$last)=conta($ris[$nometeam[$i]],'s','s');
	$scon[$nometeam[$i]]=$last-$first+1;

}

echo "<b>Max vittorie consecutive: ".max($vitt)."</b><br>".implode("<br>",array_keys($vitt,max($vitt)))."<br><br>";
echo "<b>Max pareggi consecutivi: ".max($pari)."</b><br>".implode("<br>",array_keys($pari,max($pari)))."<br><br>";
echo "<b>Max sconfitte consecutive: ".max($scon)."</b><br>".implode("<br>",array_keys($scon,max($scon)))."<br><br>";

for ($i=1;$i<=$num_squadre;$i++){

	list($first,$last)=conta($ris[$nometeam[$i]],'v','p');
	$seriepos[$nometeam[$i]]=$last-$first+1;
	list($first,$last)=conta($ris[$nometeam[$i]],'p','s');
	$serieneg[$nometeam[$i]]=$last-$first+1;	
	
}

echo "<b>Miglior serie positiva:</b><br>".implode("<br>",array_keys($seriepos,max($seriepos)))."<br>con<b> ".max($seriepos)."</b> giornate consecutive senza sconfitte. <br><br>";
echo "<b>Peggior serie negativa:</b><br>".implode("<br>",array_keys($serieneg,max($serieneg)))."<br>con<b> ".max($serieneg)."</b> giornate consecutive senza vittorie. <br><br>";
?>
</p>
<p class="default">&nbsp;</p>
