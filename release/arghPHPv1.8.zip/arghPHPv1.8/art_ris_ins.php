<?php session_start();
include("variabili.php");
if($_SESSION["user"]=="")
	die("Articolo non inserito: utente non riconosciuto. <a href=\"index.php\">Torna alla homepage</a>");

$file=fopen("news/".$_GET["id_news"].".nw",'a');

fwrite($file,"

[[reply=".$_SESSION["user"].", ".date("d.m.Y, G:i",time())."]]
".strip_tags($_POST["testo"],'<i></i><b></b><a></a>'));

fclose($file);
?>

<meta http-equiv="refresh" content="0;URL=index.php">