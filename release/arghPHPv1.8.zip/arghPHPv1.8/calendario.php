 
<div align="center">
  <p><img src="cal.jpg"></p>
  <p>&nbsp;</p>
  <table width="80%" border="1" cellspacing="0" cellpadding="0" height="8">
    <?php

$incontri=estrai_giornate($filecalendario,$nometeam);
if ($incontri[count($incontri)][1]=="") unset($incontri[count($incontri)]);
for ($i=1;$i<=count($incontri);$i++){

echo "<tr valign=\"top\">";
echo "<td width=\"47%\"><table width=\"100%\" class=\"calend\">";

echo "<tr bgcolor=\"#FFFFCC\"><td colspan=\"2\" class=\"big\"><b>".$incontri[$i][2]." </b>";
if($incontri[$i][1]<$_SESSION["gior"]) echo "<a href=\"risultati.php?giornata=".$incontri[$i][1]."\">(tabellini)</a> <a href=\"quote.php?giornata=".$incontri[$i][1]."\" target=\"_blank\">(quote)</a>";
echo "</td></tr>";

$resultFileName=glob("result/*Risultati".$incontri[$i][1].".tab");
if(@ $file=fopen($resultFileName[0],"r")){		//se � disponibile il file coi risultati
	while(!feof($file)){
	$array=explode("\t",fgets($file));
	if(array_search($array[2],$nometeam)){				//scorre il file, quando trova nomi di squadre li prende e li plotta
		echo "<tr><td width=\"85%\"><table width=\"100%\"><tr bgcolor=\"#DDDDDD\"><td colspan=\"2\" class=\"calend\">$array[2] - $array[8]</td></tr>
		<tr><td class=\"marc_left\">";
		
		$goleador=marcatori($array[2],$incontri[$i][1]);
		if ($goleador)
			for($k=0;$k<count($goleador);$k++)
				echo ucwords(strtolower($goleador[$k]))."<br>";
		
		echo "</td><td class=\"marc_right\">";
		
		$goleador=marcatori($array[8],$incontri[$i][1]);
		if ($goleador)
			for($k=0;$k<count($goleador);$k++)
				echo ucwords(strtolower($goleador[$k]))."<br>";
			
		echo "</td></tr></table></td>";
		}
	if($array[4]=="Gol")			//quando trova i gol li plotta
	echo "<td bgcolor=\"#D1FCD7\"><b>$array[5] - $array[11]</b></td></tr>";
	}
	fclose($file);
}
else{			//se i risultati non ci sono, prende gli accoppiamenti dal calendario
	$incontri2=array_slice($incontri[$i],2);
	for($j=0;$j<count($incontri2)/2;$j++){
		$t1=2*$j; $t2=2*$j+1;
		if ($nometeam[$incontri2[$t1]]!="" && $nometeam[$incontri2[$t2]]!="")
		echo "<tr><td width=\"85%\" bgcolor=\"#DDDDDD\">".$nometeam[$incontri2[$t1]]." - ".$nometeam[$incontri2[$t2]]."</td><td bgcolor=\"#D1FCD7\"></td></tr>";
		}
	}
echo "</table></td>";
if(!$i%2)
echo "</tr>";
}
?>
  </table>
  <p>&nbsp; </p>
</div>