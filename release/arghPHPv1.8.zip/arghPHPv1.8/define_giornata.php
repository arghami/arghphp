<?php
@$ind_gior=array_search($_SESSION["gior"],$giornate_valide);
$ind_start=2;
if (isset($incontri))
while ($incontri[$ind_gior][$ind_start+1]=="" && $ind_start<100){
	$ind_start++;
}
@$gior_att=array_slice($incontri[$ind_gior],$ind_start);
@array_unshift($gior_att,"ta");		//mette un elemento in pi� all'inizio per far slittare gli indici
unset($gior_att[0]);
?>