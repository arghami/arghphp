
<div align="center">
  <p class="title">Domande frequenti (FAQ)</p>
  <table width="85%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td> 
        <p class="default"><b><a href="#1">- Qual'&egrave; la configurazione migliore 
          per vedere il sito?</a></b></p>
        <p class="default"><b><a href="#2">- Ho notato un bug (=errore) nella 
          parte &quot;intelligente&quot; del sito. Che faccio? </a></b></p>
        <p class="default"><b><a href="#3">- Dopo aver inviato la formazione o 
          fatto un'offerta, mi viene dato un messaggio di conferma ma il resto 
          della schermata &egrave; bianco. </a></b></p>
        <p class="default"><b><a href="#4">- La pagina rimane completamente bianca 
          a lungo, come se stesse caricando una pagina lunghissima. </a></b></p>
        <p class="default"><b><a href="#5">- Dove posso vedere la classifica completa 
          di tutti i dati? </a></b></p>
        <p class="default"><b><a href="#6">- Ho inviato la formazione o ho fatto 
          l'offerta e voglio rivederla per controllarla. Come faccio? </a></b></p>
        <p class="default"><b><a href="#7">- Ho notato che prima della scadenza 
          del termine posso vedere chi ha mandato la formazione e a che ora l'ha 
          fatto. Perch&egrave; non fare una cosa del genere anche per le offerte?</a></b> 
        </p>
        <p class="default"> <b><a href="#8">- Quali sono i termini per dare le 
          formazioni e le offerte?</a></b> <a name="1"></a></p>
        <p class="default"><b><a href="#9">- Sono fuori per lavoro o un qualunque 
          cacchio mi impedisce di mandare la formazione in tempo.</a></b> </p>
        <p class="default"><b><a href="#10">- Il sistema per inviare le formazioni 
          &egrave; lento e/o scomodo, soprattutto quando devo togliere un giocatore 
          dal mezzo della formazione.</a></b> </p>
        <p class="default"><b><a href="#11">- Dove posso vedere i risultati dettagliati 
          delle partite? E soprattutto a che ora?</a></b> </p>
        <p class="default"><b><a href="#12">- Dove posso vedere le formazioni 
          della giornata?</a></b> </p>
        <p class="default"><a href="#13"><b>- Il tasto &quot;cont@tt@mi&quot; 
          non funziona.</b></a></p>
        <p class="default">&nbsp;</p>
        <p class="default">&nbsp; </p>
        <p class="default"><b>Qual'&egrave; la configurazione migliore per vedere 
          il sito?<a name="2"></a><br>
          </b>Dal punto di vista della funzionalit&agrave; (tipo invio formazioni 
          ecc...) va bene un qualunque browser; non sono necessari plugin java 
          o flash. Dal punto di vista grafico, il sito &egrave; testato per Internet 
          Explorer 6 o superiore, col quale viene visualizzato correttamente in 
          tutti gli elementi grafici; Netscape e Opera non visualizzano correttamente 
          alcune immagini di sfondo. La risoluzione consigliata &egrave; 1024x768.</p>
        <p class="default">&nbsp;</p>
        <p class="default">&nbsp;</p>
        <p class="default"><b>Ho notato un bug (=errore) nella parte &quot;intelligente&quot; 
          del sito. Che faccio?<a name="3"></a><br>
          </b>Contatta immediatamente il webmaster, probabilmente &egrave; un 
          suo errore.</p>
        <p class="default">&nbsp;</p>
        <p class="default">&nbsp;</p>
        <p class="default"><b>Dopo aver inviato la formazione o fatto un'offerta, 
          mi viene dato un messaggio di conferma ma il resto della schermata &egrave; 
          bianco.<a name="4"></a><br>
          </b>Perfettamente normale. Non ritengo necessario riempire di merletti 
          una pagina di conferma.</p>
        <p class="default">&nbsp;</p>
        <p class="default">&nbsp;</p>
        <p class="default"><b>La pagina rimane completamente bianca a lungo, come 
          se stesse caricando una pagina lunghissima.</b><a name="5"></a><br>
          Difficile che possa accadere,se non &egrave; un problema di congestione 
          della rete pu&ograve; essere un bug e va segnalato. Prima di andare 
          nel panico prova a premere il tasto &quot;aggiorna&quot; sul tuo browser.</p>
        <p class="default">&nbsp;</p>
        <p class="default">&nbsp;</p>
        <p class="default"><b>Dove posso vedere la classifica completa di tutti 
          i dati?</b><a name="6"></a><br>
          Cliccare su &quot;dettagli&quot; nella mini-classifica visualizzata 
          nella homepage. </p>
        <p class="default">&nbsp;</p>
        <p class="default">&nbsp;</p>
        <p class="default"><b>Ho inviato la formazione o ho fatto l'offerta e 
          voglio rivederla per controllarla. Come faccio?<a name="7"></a><br>
          </b>Il messaggio di conferma con la schermata bianca assicura al 100% 
          che l'operazione &egrave; andata in porto. In ogni caso la formazione 
          &egrave; visibile nella sezione &quot;formazioni e offerte&quot; a patto 
          di aver effettuato il login. Lo stesso vale per le offerte.</p>
        <p class="default">&nbsp;</p>
        <p class="default">&nbsp;</p>
        <p class="default"><b>Ho notato che prima della scadenza del termine posso 
          vedere chi ha mandato la formazione e a che ora l'ha fatto. Perch&egrave; 
          non fare una cosa del genere anche per le offerte?<a name="8"></a><br>
          </b>Perch&egrave; verrebbe meno il concetto dell'offerta al buio. In 
          questo modo chi fa l'offerta &egrave; costretto a farla senza sapere 
          se gli altri hanno fatto offerte, e probabilmente &egrave; costretto 
          a spendere di pi&ugrave;.</p>
        <p class="default">&nbsp;</p>
        <p class="default">&nbsp;</p>
        <p class="default"><b>Quali sono i termini per dare le formazioni e le 
          offerte?<a name="9"></a><br>
          </b>Le formazioni si possono mandare dal giorno successivo all'ultima 
          giornata giocata (ad esempio il luned&igrave; se si &egrave; giocato 
          di domenica) fino al termine riportato nella homepage. Le offerte si 
          possono fare dalla mezzanotte tra domenica e luned&igrave; fino alle 
          20 del gioved&igrave;. Il controllo sull'orario viene effettuato sia 
          all'accesso che nel momento in cui si preme il tasto di conferma, per 
          evitare che qualche furbacchione entri nella sezione e poi rimanga collegato 
          senza fare subito l'operazione e aggiri cos&igrave; il termine.</p>
        <p class="default">&nbsp;</p>
        <p class="default">&nbsp;</p>
        <p class="default"><b>Sono fuori per lavoro o un qualunque cacchio mi 
          impedisce di mandare la formazione in tempo.<a name="10"></a><br>
          </b>PRIMA che succeda questa cosa, entra in &quot;modifica profilo&quot; 
          e spunta l'opzione &quot;consenti al webmaster di modificare la tua 
          formazione&quot;. Puoi cos&igrave; comunicare la formazione al webmaster 
          con altri mezzi, ma lo devi fare con largo anticipo. Non abusare di 
          questa possibilit&agrave;.</p>
        <p class="default">&nbsp;</p>
        <p class="default">&nbsp;</p>
        <p class="default"><b>Il sistema per inviare le formazioni &egrave; lento 
          e/o scomodo, soprattutto quando devo togliere un giocatore dal mezzo 
          della formazione.</b><a name="11"></a><br>
          Arrangiatevi. Sembra strano, eppure &egrave; complicato prevedere la 
          possibilit&agrave; di estrarre un giocatore dal mezzo. Spesso conviene 
          riazzerare la formazione e ricominciare da capo piuttosto che rimuovere 
          a ritroso gli ultimi giocatori fino ad arrivare a quello di interesse.</p>
        <p class="default">&nbsp;</p>
        <p class="default">&nbsp;</p>
        <p class="default"><b>Dove posso vedere i risultati dettagliati delle 
          partite? E soprattutto a che ora?<a name="12"></a><br>
          </b>Entrare nella sezione del calendario, e cliccare su &quot;tabellini&quot; 
          nella giornata che interessa. In genere i risultati sono disponibili 
          intorno alle 16.30 - 17.00 del giorno successivo alla giornata di campionato.</p>
        <p class="default">&nbsp;</p>
        <p class="default">&nbsp;</p>
        <p class="default"><b>Dove posso vedere le formazioni della giornata?<br>
          </b>Nella sezione &quot;formazioni e offerte&quot;, dallo scadere del 
          termine fino alla domenica (o la sera stessa, se si tratta di un turno 
          infrasettimanale). Si pu&ograve; risalire alle formazioni precedenti 
          dai tabellini, oppure andando nella sezione formazioni e cliccando su 
          &quot;archivio formazioni&quot;.</p>
        <p class="default">&nbsp;</p>
        <p class="default">&nbsp;</p>
        <p class="default"><b>Il tasto cont@tt@mi non funziona.<br>
          </b>Il tasto richiama il tuo client di posta elettronica (nel 90% dei 
          casi &egrave; Outlook Express). Se non usi un programma del genere per 
          gestire la posta non si aprir&agrave; niente.</p>
        <p class="default">&nbsp;</p>
</td>
    </tr>
  </table>
  
</div>
