
<div align="center"></div>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td class="default"> 
	  <p class="title">Archivio formazioni</p>
      <p>Visualizza formazioni della giornata:
	  <form name="form1" method=GET action=index.php>
  <input type="hidden" name="section" value="<?php echo array_search("arcform",$link); ?>">
  <select name="arcgior">
	<?php

//estrae gli incontri e elimina quelli nulli
$incontri=estrai_giornate($filecalendario,$nometeam);
if ($incontri[count($incontri)][1]=="") unset($incontri[count($incontri)]);
$t=1;
while ($incontri[$t][1]){
	$giornate_valide[]=$incontri[$t][1];
	$t++;
}
@array_unshift($giornate_valide,"ta");		//mette un elemento in pi� all'inizio per far slittare gli indici
unset($giornate_valide[0]);

//crea il men� a tendina per la selezione della giornata
for ($i=1;$i<=$_SESSION["gior"];$i++){
	echo "<option";
	if ($i==$_GET["arcgior"])
	echo " selected";
	echo ">$i</option>
";
}
?>
  </select>

  <input type="submit" value="Ok">
</form>
      <p><b><i>
        <?php echo $incontri[array_search($_GET["arcgior"],$giornate_valide)][2]; ?>
        </i></b> </p>
      <p> 
        <?php


//isola la giornata specificata, eliminando eventuali elementi nulli all'inizio.
@$ind_gior_old=array_search($_GET["arcgior"],$giornate_valide);
$ind_start=2; //i primi due elementi non servono (sono "gior_di_A" e "fantag.")
if (isset($incontri)) {
	while ($incontri[$ind_gior_old][$ind_start+1]=="" && $ind_start<100){
		$ind_start++;
	}
}
@$gior_att_old=array_slice($incontri[$ind_gior_old],$ind_start); //elimina i primi 2 elementi e gli eventuali altri elementi nulli
@array_unshift($gior_att_old,"ta");
unset($gior_att_old[0]);


//stampa delle formazioni
if($_GET["arcgior"]>$_SESSION["gior"] || ($_GET["arcgior"]==$_SESSION["gior"] && time()<strtotime($_SESSION["term"]) ))
    echo "Puoi vedere solo le formazioni di giornate precedenti alla ".$_SESSION["gior"].".</p><p>";
else{
    echo "<table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"5\">";

    for($i=1;$i<=count($gior_att_old);$i++){
    	if ($i % 2)
			echo "<tr class=\"default\">";
    	echo "<td width=\"50%\">";
		echo "<p><b>",$nometeam[$gior_att_old[$i]],"</b><br>";

		// cerca la formazione negli ultimi 4 file e la stampa.
		$j=0; $find=0;
		while ($j<4 && ($_GET["arcgior"]-$j)>0 && !$find){
	    	$filen="users/".$gior_att_old[$i]."_form_".($_GET["arcgior"]-$j).".txt";
	    	if (@ $formaz=fopen($filen,'r'))
				$find=1;
	    	$j++;
		}
		if (!$find) echo "Nessuna formazione inviata nelle ultime $j giornate";
    	else{
			echo "(formazione inviata il ",date ("d.m.Y, G:i", filemtime($filen)),")";
		if ($j>1) echo "(precedente)";
		echo "<br><br>";
		while (!feof($formaz))
	    	echo fgets($formaz),"<br>";
    	fclose($formaz);
	}
    //se l'utente � il webmaster, fa comparire il link di modifica
	if ($_SESSION["user"]=="webmaster")
		echo "<br><a href=\"index.php?section=".array_search("modifica",$link)."&gior=".$_GET["arcgior"]."&id=".$gior_att_old[$i]."\">modifica</a>";
	echo "</p>";
    echo "</td>
";
    if (! ($i % 2)) echo "</tr>";
    }
echo "</table>";
}
?>
      </p>
    </td>
  </tr>
</table>
