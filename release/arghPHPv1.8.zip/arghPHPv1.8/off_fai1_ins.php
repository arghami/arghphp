<?php session_start();
include("variabili.php");
echo "<link rel=\"stylesheet\" href=\"style.css\" type=\"text/css\">
<p class=\"default\">
";
if($_SESSION["user"]=="guest")
	die("L'utente \"guest\" non pu� fare offerte. <a href=\"index.php\">Torna alla homepage</a>");

$weekday=date("w");
if (!$weekday) $weekday=7;
$hour=date("G");
for ($fase=1; $fase<4; $fase++) {
	if (!isset($oramercato[$fase]) || $weekday>$giornomercato[$fase] || ($weekday==$giornomercato[$fase] && $hour>=$oramercato[$fase]))
		continue;
	else break;
}
	
if ($fase!=1)
	die("E' scaduto il termine per inviare l'offerta.");

$tmp=explode(" ",$_POST[menu]);
$tmp2=explode(" ",$_POST[menu2]);
$weekmercato=$_GET["weekmercato"];

if ($tmp[0]!=$tmp2[0])
  die("L'offerta non � corretta, i ruoli dei due giocatori non sono uguali.<br><a href=javascript:history.back()>Indietro</a>");
$str_inf="";
if ($_POST[inf]!="")
	$str_inf="\tsi";
else
	$str_inf="\tno";
$str=$_POST[menu]."\t".max(0,(int)$_POST[cr])."\t".$_POST[menu2].$str_inf."\n";

if (@$offerte=file("users/".$_SESSION["id"]."_off_".$weekmercato)) {
	if (count($offerte)<$maxofferte)
		$offerte[]=$str;
	else
		$offerte[$maxofferte-1]=$str;
}
else
	$offerte[0]=$str;
$file=fopen("users/".$_SESSION["id"]."_off_".$weekmercato,'w');
foreach($offerte as $value)
	fwrite($file,stripslashes($value));
fclose($file);

$offer=explode("\t",$str);
echo "Giocatore richiesto: ".$offer[0]."<br>";
echo "Crediti offerti: ".$offer[1]."<br>";
echo "Taglio: ".$offer[2]."<br>";
echo "Lista infortunati: ".$offer[3]."<br><br>";
echo "Offerta inserita. <a href=index.php>Torna alla homepage</a>";
?>