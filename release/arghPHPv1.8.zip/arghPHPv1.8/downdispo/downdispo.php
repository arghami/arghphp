<?php
function loadDispo($gior){
	//controllo se il file creato � troppo recente
	if (@filemtime("downdispo/dispo$gior.php")<time()-30*60){
		//remoto
		$ch = curl_init("http://www.fantacalcio.kataweb.it/fantamanager/index.php?page=indisponibili&cmp=A&giornata=$gior");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$res = curl_exec($ch);
		curl_close($ch);
		$file = explode("\n",$res);

		//locale
		//$file = file("http://www.fantacalcio.kataweb.it/fantamanager/index.php?page=indisponibili&cmp=A&giornata=20");
		$filedispo = fopen("downdispo/dispo$gior.php","w");
		fwrite($filedispo, "<?php\n\$dispo = array(); \n\n");
		for ($i=0; $i<count($file); $i++){
			list($cod, $disp, $stato) = explode("\t",str_replace("\n","",$file[$i]));
			if ($cod!=""){
				fwrite($filedispo, "\$dispo[$cod] = array(\"dispo\"=>$disp, \"stato\"=>$stato); \n");
			}
		}
		fwrite($filedispo, "?>");
		fclose($filedispo);
	}
}
?>