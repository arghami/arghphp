<?php
if($_GET["gior"]>$_SESSION["gior"] || ($_GET["gior"]==$_SESSION["gior"] && time()<strtotime($_SESSION["term"]) ))
	echo "Puoi modificare solo le formazioni gi� inserite nell'archivio formazioni.";

else{
	echo "<form action=\"modifica_fai.php?gior=".$_GET["gior"]."&id=".$_GET["id"]."\" method=\"post\">
	<textarea rows=\"20\" cols=\"50\" name=\"formazione\">";
	@readfile("users/".$_GET["id"]."_form_".$_GET["gior"].".txt");
	echo "</textarea><br><br>";
	echo "<input type=\"submit\" value=\"Invia\"></form>";
}
?>

