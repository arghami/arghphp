<p><font face="Verdana" size="2">   <?php
// cambio l'id e prendo possesso dell'allenatore interessato
$file=fopen("users/users.us",'r');
echo "Formazioni modificabili:<br><br>";
while (!feof($file)){
$info=explode("\t",fgets($file));
if ($info[3]!=0)
echo "<a href=cambiaid.php?newid=$info[1]>$info[0] (id $info[1])<br>";
}
?>