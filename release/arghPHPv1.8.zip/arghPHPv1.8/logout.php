<?php

session_start();
unset($_SESSION["user"],$_SESSION["id"],$_SESSION["lastlog"]);
echo "<head>
<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">
</head>";


?>

