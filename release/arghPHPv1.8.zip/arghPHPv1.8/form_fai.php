<a name="top"></a><p class="title">Gestione formazione</p>
<p><font face="Verdana" size="2">   <?php
$user=$_SESSION["user"];
$id=$_SESSION["id"];
$pl=$_GET[pl];

//includo le informazioni per il caricamento delle disponibilit�
$nomefileassoc=glob("*Risultati*Tutti*");
$righe = file($nomefileassoc[0]);
//questo vettore mi permette di associare al nome di un giocatore il suo codice
$vettAssoc = array();
for ($i=1; $i<count($righe); $i++){
	$dati = explode("\t",$righe[$i]);
	$vettAssoc[$dati[0]."(".$dati[1].")"] = $dati[3];
}
include("downdispo/downdispo.php");
loadDispo($gior);
include("downdispo/dispo$gior.php");

if(time()>strtotime($_SESSION["term"]))
    echo "Spiacente, sei fuori tempo massimo per l'inserimento della formazione. <a href=\"javascript:history.back()\">indietro</a>";
else
   if ($id) include("form_fai2.php");
   else include("form_fai2w.php");
?>