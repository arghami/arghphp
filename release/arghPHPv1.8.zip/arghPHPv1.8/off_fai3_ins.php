<?php session_start();
include("variabili.php");
echo "<link rel=\"stylesheet\" href=\"style.css\" type=\"text/css\">
<p class=\"default\">
";

$weekday=date("w");
if (!$weekday) $weekday=7;
$hour=date("G");
for ($fase=1; $fase<4; $fase++)
		if (!isset($oramercato[$fase]) || $weekday>$giornomercato[$fase] || ($weekday==$giornomercato[$fase] && $hour>=$oramercato[$fase]))
		continue;
	else break;

if ($fase!=3)
	die("E' scaduto il termine per presentare le buste");

$weekmercato=$_GET["weekmercato"];

if (@$offerte=file("users/".$_SESSION["id"]."_ril_".$weekmercato)) {
	for ($i=0;$i<count($offerte);$i++) {
		$offerta=explode("\t",$offerte[$i]);
		if ($_POST["off$i"]!=""){
			$offerta[0]=str_replace("\n","",$offerta[0]);
			$offerta[1]=$_POST["off$i"];
			$offerta[2]=$_POST["menu$i"];
			$offerte[$i]=implode("\t",$offerta)."\n";
		}
	}
}
$file=fopen("users/".$_SESSION["id"]."_ril_".$weekmercato,'w');
foreach($offerte as $value)
	fwrite($file,stripslashes($value));
fclose($file);

echo "Riepilogo rilanci: ".$str."<br>";
foreach($offerte as $value)
	echo $value."<br>";
echo "Rilancio inserito.<a href=index.php>Torna alla homepage</a>";
?>