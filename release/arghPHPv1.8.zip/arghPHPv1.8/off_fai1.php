
<p class="title">Mercato libero - fase 1 (chiamate) </p>

  <table width="100%" border="1" cellpadding="5" cellspacing="0" class="default" >
  <form name=form method=post action="off_fai1_ins.php<?php echo "?weekmercato=$weekmercato"; ?>">
  <tr> 
      <td width="50%" class="default">Seleziona nell'elenco sottostante il giocatore 
        per cui vuoi fare l'offerta. <?php if($maxofferte) echo "Ricorda che puoi fare solo $maxofferte offerte alla 
        settimana; se ne farai un'altra, questa sovrascriver&agrave; l'ultima offerta fatta."; ?><br>
        <div class="mini">Lista aggiornata al <?php echo date ("d/m/Y", filemtime($nomefilesvinc[0])); ?>.</div></td>
      <td width="50%" class="default">Seleziona dalla tua squadra l'eventuale giocatore 
      da tagliare per far posto al nuovo arrivo. Il ruolo del giocatore deve essere 
      lo stesso del giocatore per cui si fa l'offerta.</td>
  </tr>
  <tr> 
    <td width="50%"> 
      <select name="menu" size="15">
        <?php 
$file=fopen($nomefilesvinc[0],'r');
while (!feof($file)){
	$temp_arr=explode("\t",fgets($file));
	$gioc=$temp_arr[2]." ".$temp_arr[0]." (".$temp_arr[1].")";
    echo "<option>$gioc</option>
";
}
?>
      </select>
    </td>
    <td width="50%" class="default"> 
      <div align="right"> 
        <select name="menu2" size="15">
          <?php
if (@ $file=fopen($filerose,'r')){
	arrivaa($nometeam[$_SESSION["id"]],$file);
	arrivaa("Nome",$file);
	$squadra[2]="a";
	while ($squadra[2]!="") {
		$squadra=explode("\t",fgets($file));
		echo "<option>".substr($squadra[1],0,1)," ",$squadra[2],"</option>
		";
	}
	
	while (substr($crediti,0,7)!="Crediti" && !feof($file))
		list(,$crediti)=explode("\t",fgets($file));
	$crediti=substr($crediti,17);
	fclose($file);
}

?>
        </select>
      </div>
    </td>
  </tr>
  <tr> 
    <td colspan="2">
        <div align="center" class="default_noalign">
          <p>crediti offerti: 
            <input type="text" name="cr" size="3">
            (Hai 
            <?php echo $crediti; ?>
            crediti) <br>
            <input type="checkbox" value="checkbox" name="inf">
            Inserisci il giocatore scartato in lista infortunati<br>
            <input type="submit" name="Submit" value="Conferma offerta">
          </p>
          <p align="left"><i><b>Note:</b></i><br>
            - L'offerta NON VIENE analizzata dal server, &egrave; solo testuale. 
            Quindi se sbagli a fare qualcosa (ad esempio metti in lista infortunati 
            un giocatore che in realt&agrave; sta bene, oppure metti pi&ugrave; 
            crediti di quelli che hai, ecc....)  non verr&agrave; visualizzato nessun messaggio di errore.<br>
            - In caso di lista infortunati non aggiungere i crediti dell'operazione, 
          inserire solo i crediti (anche 0) per l'ingaggio del nuovo giocatore.</p>
        </div>
    </td>
  </tr>
  </form>
  <tr>
    <td colspan="2"><p>&nbsp;</p>
      <p>Offerte gi&agrave; fatte:</p></td></tr>
	  <?php 
	  
	  if (@$offerte=file("users/".$_SESSION["id"]."_off_".$weekmercato)) {
	  	$ind=0;
		foreach ($offerte as $value){
			$offerta=explode("\t",$value);
			echo "<tr><form name=form method=post action=\"off_fai1_rem.php?weekmercato=$weekmercato\"><td>$offerta[0]<br> $offerta[1] cr.<br>Eventuale taglio: $offerta[2]<br> L.I.=$offerta[3] <input type=\"hidden\" name=\"menu\" value=\"$ind\"</td>
				<td><input type=\"submit\" name=\"Submit\" value=\"Annulla offerta\"></td></form></tr>";
			$ind++;
		}
	  }
	  ?>
  </tr>
</table>
