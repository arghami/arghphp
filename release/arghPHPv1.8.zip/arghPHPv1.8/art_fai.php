<p class="title">Scrivi articolo</p>
<form name="form1" method="post" action="art_fai_ins.php">
  <p class=default> Inserisci qui sotto il testo del tuo articolo. Ricorda che 
    una volta inviato l'articolo non potr&agrave; pi&ugrave; essere modificato! 
    Puoi inserire tag html per migliorare la formattazione del testo; sono permessi 
    solo i tag &lt;b&gt; &lt;/b&gt;, &lt;i&gt; &lt;/i&gt; per ottenere rispettivamente 
    il grassetto e il corsivo. Ad esempio se scrivi:<br>
    -&nbsp;&nbsp;&nbsp;Al termine della stagione, il &lt;b&gt;Mad For It&lt;/b&gt; 
    si aggiudica il &lt;i&gt;campionato&lt;/i&gt;, l'&lt;b&gt;Henry&lt;/b&gt; 
    la coppa. &lt;b&gt;&lt;i&gt;A presto!&lt;/i&gt;&lt;/b&gt;<br>
    <br>
    verr&agrave; visualizzato questo:<br>
    -&nbsp;&nbsp;&nbsp;Al termine della stagione, il <b>Mad For It</b> si aggiudica 
    il <i>campionato</i>, l'<b>Henry</b> la coppa. <b><i>A presto!<br>
    </i></b><br>
    Verr&agrave; tenuto conto dei ritorni a capo.</p>
  <p class=default>E' inoltre ammesso il tag &lt;a&gt;&lt;/a&gt; per i link. Ad esempio scrivendo &lt;a href=&quot;http://www.fantacalcio.it&quot;&gt;Sito fantacalcio&lt;/a&gt; si ottiene questo:</p>
  <p class="default"><a href="http://www.fantacalcio.it">Sito fantacalcio</a></p>
  <p class=default>Ogni altro tag html sar&agrave; 
    eliminato.</p>
  <p class=default> Consiglio: puoi scrivere il tuo articolo offline (ad esempio 
    utilizzando il notepad, o word) e poi collegarti in un secondo momento e incollare 
    il testo del tuo articolo nel riquadro. </p>
  <table width="600" border="0" cellspacing="0" cellpadding="0">
    <tr valign="top"> 
      <td width="60"><p class=default>Titolo</p></td>
      <td width="540"> 
        <input type="text" name="titolo" size="64" value="">
      </td>
  </tr>
    <tr valign="top"> 
      <td width="60"><p class=default>Testo</p></td>
      <td width="540"> 
        <textarea name="testo" cols="60" rows="15"></textarea>
      </td>
  </tr>
</table>
    
  <p>
    <input type="submit" name="Submit" value="Invia articolo">
  </p>
</form>
