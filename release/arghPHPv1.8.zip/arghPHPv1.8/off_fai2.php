
<p class="title">Mercato libero - fase 2 (comunicazione rilancio) </p>

  <p>&nbsp;</p>
  <table width="90%" border="1" cellpadding="5" cellspacing="0" class="default" align="center">
  <tr> 
    <td colspan="2"> 
	  <p class="default">Questi sono i giocatori chiamati, con le offerte dei vari allenatori. Colui che ha offerto di pi&ugrave; &egrave; il <em>chiamante</em> (a meno di casi particolari, vedi regolamento), ed &egrave; l'unico che alle buste pu&ograve; ribadire l'offerta iniziale, ritirandosi di fatto dall'asta. Gli altri dovranno mettere in busta almeno un credito in pi&ugrave;. </p>
	</td></tr>
	    <?php 
	$giocatore=giocatori_chiamati($weekmercato,$nometeam);
	@$rilancirichiesti=file_get_contents("users/".$_SESSION["id"]."_ril_".$weekmercato);
		while (list($chiave, $valore) = each($giocatore)){
    		if (@!(strpos($rilancirichiesti,$chiave)===false))
				echo "<tr height=25><form name=form method=post action=\"off_fai2_rem.php?weekmercato=$weekmercato\">";
			else
				echo "<tr height=25><form name=form method=post action=\"off_fai2_ins.php?weekmercato=$weekmercato\">";
			echo "<td><input type=\"hidden\" name=\"menu\" value=\"$chiave\"><b>".$chiave."</b> ".str_replace("\n",", ",$valore)."</td><td align=\"center\">";
			if (@!(strpos($rilancirichiesti,$chiave)===false))
				echo "<input type=\"submit\" name=\"Submit\" value=\"Annulla rilancio\"></td></form></tr>
		";
			else
				echo "<input type=\"submit\" name=\"Submit\" value=\"Rilancia\"></td></form></tr>
		";
	}
	?>
	  <div align="center">
      </div>
</table>
