<?php session_start();
include("variabili.php");
echo "<link rel=\"stylesheet\" href=\"style.css\" type=\"text/css\">
<p class=\"default\">
";
if($_SESSION["user"]=="guest")
	die("L'utente \"guest\" non pu� fare offerte. <a href=\"index.php\">Torna alla homepage</a>");

$weekday=date("w");
if (!$weekday) $weekday=7;
$hour=date("G");
for ($fase=1; $fase<4; $fase++)
	if ($oramercato[$fase]=="" || $weekday>$giornomercato[$fase] || ($weekday==$giornomercato[$fase] && $hour>$oramercato[$fase]))
		continue;
	else break;

if ($fase!=1)
	die("E' scaduto il termine per rimuovere l'offerta.");

$weekmercato=$_GET["weekmercato"];

if (@$offerte=file("users/".$_SESSION["id"]."_off_".$weekmercato)) {
	$str=$offerte[$_POST["menu"]];
	unset($offerte[$_POST["menu"]]);
}

$file=fopen("users/".$_SESSION["id"]."_off_".$weekmercato,'w');
foreach($offerte as $value)
	fwrite($file,$value);
fclose($file);

echo "Offerta rimossa: ".$str."<br>";
echo "<a href=index.php>Torna alla homepage</a>";
?>