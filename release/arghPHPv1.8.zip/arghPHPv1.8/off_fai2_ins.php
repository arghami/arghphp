<?php session_start();
include("variabili.php");
echo "<link rel=\"stylesheet\" href=\"style.css\" type=\"text/css\">
<p class=\"default\">
";
if($_SESSION["user"]=="guest")
	die("L'utente \"guest\" non pu� fare offerte. <a href=\"index.php\">Torna alla homepage</a>");

$weekday=date("w");
if (!$weekday) $weekday=7;
$hour=date("G");
for ($fase=1; $fase<4; $fase++)
		if (!isset($oramercato[$fase]) || $weekday>$giornomercato[$fase] || ($weekday==$giornomercato[$fase] && $hour>=$oramercato[$fase]))
		continue;
	else break;
if ($fase!=2)
	die("E' scaduto il termine per presentare l'intenzione di rilancio.");

$weekmercato=$_GET["weekmercato"];

$str=$_POST[menu]."\n";

if (@$offerte=file("users/".$_SESSION["id"]."_ril_".$weekmercato)) {
	if(array_search($str,$offerte)===false)
		$offerte[]=$str;
}
else
	$offerte[0]=$str;
$file=fopen("users/".$_SESSION["id"]."_ril_".$weekmercato,'w');
foreach($offerte as $value)
	fwrite($file,stripslashes($value));
fclose($file);

echo "Giocatore oggetto del rilancio: ".$str."<br>";
echo "Intenzione di rilancio inserita. Torna nella terza fase di mercato per specificare l'entit� del rilancio. <a href=index.php>Torna alla homepage</a>";
?>