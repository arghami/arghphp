<?php
session_start();
include("variabili.php");

$incontri=estrai_giornate($filecalendario,$nometeam);
if ($incontri[count($incontri)][1]=="") unset($incontri[count($incontri)]);
$t=1;
while ($incontri[$t][1]){
	$giornate_valide[]=$incontri[$t][1];
	$t++;
}
@array_unshift($giornate_valide,"ta");		//mette un elemento in pi� all'inizio per far slittare gli indici
unset($giornate_valide[0]);

//controllo sull'orario. Memorizza la prossima giornata nella var di sessione "gior"

if (!session_is_registered("gior")){
	$file=fopen("SerieA.txt",'r');
	$time=0; $gior=0;
	
	while (!feof($file) && (($time+24*3600)<time() || @!array_search($gior,$giornate_valide)) ){
		$gior++;
		$time=strtotime(fgets($file));
		$term=date("j M Y G:i",$time-$anticipo*60);
	}
	@$ind_gior=array_search($gior,$giornate_valide);
	$_SESSION["gior"]=$gior;
	$_SESSION["term"]=$term;
	$_SESSION["descr"]=$incontri[$ind_gior][2];
	fclose($file);
   
	session_write_close();
}

include("define_giornata.php");

$user=$_GET[user];
$pass=$_GET[pass];  //si prende le variabili passate dalla POST del form di login
$valid=0;
$handle=fopen("users/users.us","r");
while(!$valid&&!feof($handle)){			//si interrompe se viene trovato l'user oppure alla fine del file
	$dati=explode("\t",fgets($handle));
	if($dati[0]==$user)
	    $valid=1;
	}
fclose($handle);
if (!$valid)  {		//se l'utente non � stato trovato
	echo "<error>Nome utente o password non validi.</error>";
	die();
}
	else{
	$id=$dati[1];
	$password=$dati[2];
	if (crypt($pass,"key")!=$password)	//se la password non corrisponde
		{
		echo "<error>Nome utente o password non validi.</error>";
		die();
		}
	else
	{
	
  	if(time()>strtotime($_SESSION["term"])){ //il termine � scaduto
      echo "<error>Spiacente, sei fuori tempo massimo per l'inserimento della formazione.</error>";
      die();
    }
    
  	if (@ $file=fopen($filerose,'r')){
    	arrivaa($nometeam[$id],$file);
    	arrivaa("Nome",$file);
    	$temp[2]="a";
    	$i=0;
    	while ($temp[2]!=""){
    		$temp=explode("\t",fgets($file));
    		$ruolo[$i]=substr($temp[1],0,1);
    		$squadra[$i]=$temp[2];
    		$i++;
    	}
    	fclose($file);
    }
    $form=explode("-",$_GET[form]);
    
    $file=fopen("users/".$id."_form_".$_SESSION["gior"].".txt","wb");
    for($i=0;$i<count($form);$i++){
    	fwrite($file,$ruolo[$form[$i]]." ".$squadra[$form[$i]]);
    	fwrite($file,"
    ");  //scrive un ritorno a capo nel file
    	$ruoloschierato[]=$ruolo[$form[$i]];
    if ($i==10)
    	fwrite($file,"
    ");  //scrive un ritorno a capo nel file (quello tra titolari e riserve)
    }
    if($_GET["altro"]!="")
    	fwrite($file,"
    ".$_GET["altro"]);
    fclose($file);
    
    $file=fopen("users/".$id."_form_".$_SESSION["gior"].".txt","r");
    echo "
    Formazione correttamente inserita.
    Questa � la formazione che hai inserito:
    
    ";
    while(!feof($file)){
       echo fgets($file),"
";
    }
    fclose($file);
    
    $ruoliusati=array_count_values(array_slice($ruoloschierato,0,11));
    $modulo=$ruoliusati["D"]."-".$ruoliusati["C"]."-".$ruoliusati["A"];
    if (!array_search($modulo,$moduliammessi)){
    	echo "Attenzione, hai schierato la squadra secondo un modulo non ammesso ($modulo). I moduli ammessi sono: ";
    	foreach($moduliammessi as $value) echo $value.", ";
    }
  }
}
?>