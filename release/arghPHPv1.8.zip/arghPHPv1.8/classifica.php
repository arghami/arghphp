<head>

<link rel="stylesheet" href="style.css" type="text/css">
<title>Classifica</title>

<script type="text/javascript">
function NascondiColonna(IDtabella,voce){
ModificaColonna(IDtabella,voce,"none");
}

function MostraColonna(IDtabella,voce){
ModificaColonna(IDtabella,voce,"");
}

function ModificaColonna(IDtabella,voce,display){
ths=document.getElementById(IDtabella).tHead.rows[0].cells;
for(i=0;i<ths.length;i++){
    htext=ths[i].firstChild.nodeValue;
    if(htext==voce)
        colonna=i;
    }
if(colonna>=ths.length) return;
ths[colonna].style.display=display;
trs=document.getElementById(IDtabella).tBodies[0].rows;
for(i=0;i<trs.length;i++){
    tds=trs[i].cells;
    tds[colonna].style.display=display;
    }
}

function Ripristina(IDtabella){
var trs=document.getElementById(IDtabella).tHead.rows;
ths=trs[0].cells;
for(i=0;i<ths.length;i++) ths[i].style.display="";
trs=document.getElementById(IDtabella).tBodies[0].rows;
for(i=0;i<trs.length;i++){
    tds=trs[i].cells;
    for(j=0;j<tds.length;+j++)
        tds[j].style.display="";
    }
} 

function cambiacolonna(nomecheck,IDcheck){
if (document.forms[0].elements[IDcheck].checked)
	MostraColonna('classifica',nomecheck);
else
	NascondiColonna('classifica',nomecheck);
}
	
function colonneiniziali (){
NascondiColonna('classifica','Presidente');
NascondiColonna('classifica','PcV');
NascondiColonna('classifica','PcN');
NascondiColonna('classifica','PcP');
NascondiColonna('classifica','PfV');
NascondiColonna('classifica','PfN');
NascondiColonna('classifica','PfP');
NascondiColonna('classifica','MI');
NascondiColonna('classifica','RcF');
NascondiColonna('classifica','RcS');
NascondiColonna('classifica','RfF');
NascondiColonna('classifica','RfS');
NascondiColonna('classifica','PMin');
NascondiColonna('classifica','PMax');
NascondiColonna('classifica','PDSt');
NascondiColonna('classifica','PAvv');
NascondiColonna('classifica','TMin');
NascondiColonna('classifica','TMax');
NascondiColonna('classifica','TDSt');
NascondiColonna('classifica','TAvv');
NascondiColonna('classifica','SomP');
NascondiColonna('classifica','SomT');
}


</script>
</head>

<body onload=javascript:colonneiniziali();>
<?php
include("variabili.php");
?>
<p class="title">Classifica</p>
  
<table id="classifica" class="default_bold" border="1" bordercolor="#000000" cellspacing="0" align="center">
  <thead> 
  <tr> 
    <th width="20">&nbsp;</th>
    <th width="180">Squadra</th>
    <th width="35">Presidente</th>
<?php
$file=fopen($fileclassifica,'r');
scorri($file,2);
$rigo=explode("\t",rtrim(fgets($file)));
for($i=4;$i<33;$i++)
echo "<th width=\"20\">$rigo[$i]</th>
";
?>
  </tr>
  </thead> <tbody> 
  <?php
//plottaggio classifica

$i=1;
while(!feof($file)){
   $rigo=explode("\t",fgets($file));
   if (count($rigo)<2) break;
   echo "<tr bgcolor=$backcolor[$i]>
   <td>$i</td>
   <td>$rigo[1]</td>
   <td><font size=1>$rigo[3]</font></td>
   <td><font color=\"#000099\" >$rigo[4]</font></td>";
   $color=array(5=>"","","","","","","color=\"#009900\"","color=\"#999900\"","color=\"#990000\"","","","","","","color=\"#009900\"","color=\"#990000\"","","","","","","","","","","","","");
for ($j=5;$j<33;$j++)
   echo "<td><font size=1 $color[$j]>$rigo[$j]</font></td>
   ";
  $i++;  
  }
fclose($file);
?>
  </tbody> 
</table>
  

<p class="default">Parametri visualizzabili:</p>
<form>
  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="default">
    <tr> 
      <td width="33%"> 
        <p> 
          <input type="checkbox" id="Presidente" value="checkbox" onclick=javascript:cambiacolonna("Presidente",0);>
          Presidente<br>
          <input type="checkbox" id="PT" value="checkbox" onclick=javascript:cambiacolonna("PT",1); checked>
          <b> Punti (PT)</b><br>
          <input type="checkbox" id="PcV" value="checkbox" onclick=javascript:cambiacolonna("PcV",2);>
          Vinte in casa (PcV)<br>
          <input type="checkbox" id="PcN" value="checkbox" onclick=javascript:cambiacolonna("PcN",3);>
          Nulle in casa (PcN)<br>
          <input type="checkbox" id="PcP" value="checkbox" onclick=javascript:cambiacolonna("PcP",4);>
          Perse in casa (PcP)<br>
          <input type="checkbox" id="PfV" value="checkbox" onclick=javascript:cambiacolonna("PfV",5);>
          Vinte fuori casa (PfV)<br>
          <input type="checkbox" id="PfN" value="checkbox" onclick=javascript:cambiacolonna("PfN",6);>
          Nulle fuori casa (PfN)<br>
          <input type="checkbox" id="PfP" value="checkbox" onclick=javascript:cambiacolonna("PfP",7);>
          Perse fuori casa (PfP)<br>
          <input type="checkbox" id="PtV" value="checkbox" onclick=javascript:cambiacolonna("PtV",8); checked>
          <b>Vinte totali (PtV)</b><br>
          <input type="checkbox" id="PtN" value="checkbox" onclick=javascript:cambiacolonna("PtN",9); checked>
          <b>Nulle totali (PtN)<br>
          <input type="checkbox" id="PtP" value="checkbox" onClick=javascript:cambiacolonna("PtP",10); checked name="checkbox">
          <b>Perse totali (PtP)</b><br>
          <input type="checkbox" id="MI" value="checkbox" onClick=javascript:cambiacolonna("MI",11); name="checkbox2">
          </b>Media inglese (MI)<br>
          <input type="checkbox" id="RcF" value="checkbox" onClick=javascript:cambiacolonna("RcF",12); name="checkbox2">
          Reti fatte in casa (RcF)<br>
          <input type="checkbox" id="RcS" value="checkbox" onClick=javascript:cambiacolonna("RcS",13); name="checkbox2">
          Reti subite in casa (RcS)<br>
          <input type="checkbox" id="RfF" value="checkbox" onClick=javascript:cambiacolonna("RfF",14); name="checkbox2">
          Reti fatte fuori casa (RfF) </p>
      </td>
      <td width="33%"> 
        <input type="checkbox" id="RfS" value="checkbox" onclick=javascript:cambiacolonna("RfS",15);>
        Reti subite fuori casa (RfS)<br>
        <input type="checkbox" id="RtF" value="checkbox" onclick=javascript:cambiacolonna("RtF",16); checked>
        <b>Reti totali fatte (RtF)</b><br>
        <input type="checkbox" id="RtS" value="checkbox" onclick=javascript:cambiacolonna("RtS",17); checked>
        <b> Reti totali subite (RtS)</b><br>
        <input type="checkbox" id="PMed" value="checkbox" onclick=javascript:cambiacolonna("PMed",18); checked>
        <b> Parziale squadra medio (PMed)</b><br>
        <input type="checkbox" id="PMin" value="checkbox" onclick=javascript:cambiacolonna("PMin",19);>
        Parziale squadra minimo (PMin)<br>
        <input type="checkbox" id="PMax" value="checkbox" onClick=javascript:cambiacolonna("PMax",20); name="checkbox3">
        Parziale squadra massimo (PMax)<br>
        <input type="checkbox" id="PDSt" value="checkbox" onClick=javascript:cambiacolonna("PDSt",21); name="checkbox3">
        Deviazione standard del parziale (PDSt)<br>
        <input type="checkbox" id="PAvv" value="checkbox" onClick=javascript:cambiacolonna("PAvv",22); name="checkbox3">
        Parziale avversario medio (PAvv)<br>
        <input type="checkbox" id="TMed" value="checkbox" onClick=javascript:cambiacolonna("TMed",23); checked name="checkbox3">
        <b>Totale squadra medio (TMed)</b><br>
        <input type="checkbox" id="TMin" value="checkbox" onClick=javascript:cambiacolonna("TMin",24); name="checkbox3">
        Totale squadra minimo (TMin)<br>
        <input type="checkbox" id="TMax" value="checkbox" onClick=javascript:cambiacolonna("TMax",25); name="checkbox3">
        Totale squadra massimo (TMax)<br>
        <input type="checkbox" id="TDSt" value="checkbox" onClick=javascript:cambiacolonna("TDSt",26); name="checkbox3">
        Deviazione standard del totale (TDSt)<br>
        <input type="checkbox" id="TAvv" value="checkbox" onClick=javascript:cambiacolonna("TAvv",27); name="checkbox3">
        Totale avversario medio (TAvv)<br>
        <input type="checkbox" id="SomP" value="checkbox" onClick=javascript:cambiacolonna("SomP",28); name="checkbox3">
        Sommatoria dei parziali (SomP)<br>
        <input type="checkbox" id="SomT" value="checkbox" onClick=javascript:cambiacolonna("SomT",29); name="checkbox3">
        Sommatoria dei totali (SomT) </td>
    </tr>
  </table>
</form>
</body>
</HTML>