<style type="text/css">
<!--
.Stile1 {color: #FF0000}
-->
</style>
<?php

$annate = glob("storico/*.txt");
$comp = array();
for ($i=0; $i<count($annate); $i++){
	include ($annate[$i]);
}

$anni = array_keys($comp);

?>
<div align="center"><img src="albo.jpg"></div>
<p align="left">&nbsp;</p>
<p align="left" class="title">Le stagioni scorse</p>
<table border="1" align="center" cellpadding="2" cellspacing="0" class="default">
  <tr class="big">
    <td align="center">Anno</td>
    <td align="center"><img src="scudetto.jpg"/></td>
    <td align="center"><img src="coppa-italia.jpg"/></td>
    <td align="center"><img src="b.gif"/></td>
    <td align="center">Squadre</td>
  </tr>
<?php
for ($i=count($anni)-1; $i>=0; $i--){
	$classCamp = $comp[$anni[$i]]['Campionato'];
	$classCopp = $comp[$anni[$i]]['Coppa'];
	$scudetti[$classCamp[0]] ++ ;
	$coppe[$classCopp[0]] ++;
	$retr[$classCamp[count($classCamp)-1]] ++;
	$retr[$classCamp[count($classCamp)-2]] ++;

	$col = $i%2==0?"#D8FEFD":"#FFFFCC";
	echo
  "<tr bgcolor=\"$col\">
    <td align=\"center\">&nbsp;<b>{$anni[$i]}</b>&nbsp;</td>
    <td align=\"center\">&nbsp;{$classCamp[0]}&nbsp;</td>
    <td align=\"center\">&nbsp;{$classCopp[0]}&nbsp;</td>
    <td align=\"center\">&nbsp;".$classCamp[count($classCamp)-2]."<br/>".$classCamp[count($classCamp)-1]."&nbsp;</td>
    <td align=\"center\">&nbsp;".count($classCamp)."&nbsp;</td>
  </tr>";
}
?>
</table>
<p>&nbsp;</p>
<p class="title">Classifica Rimet</p>

<?php
//calcolo la classifica rimet.

$rimet = array();
$rimetTotal = array();
$rimetDetail = array();
while (list($anno, $ris) = each($comp)){
	while (list($nomecomp, $class) = each ($ris)){
		while (list($pos, $squadra) = each ($class)){
			$rimet[$squadra] += count($class)-$pos;
			if ($rimetDetail[$squadra][$anno]!="") {
				$rimetDetail[$squadra][$anno] .= "+".(count($class)-$pos);
			}
			else {
				$rimetDetail[$squadra][$anno] = count($class)-$pos;
				$rimetTotal[$squadra]++;
			}
		}
	}
}

while (list($key,)=each($rimet)){
  //$rimet[$key] = 0.1*round(10*($rimet[$key]/$rimetTotal[$key]+0.2*$rimetTotal[$key]));
}
arsort($rimet);

?>
<p class="default"><i>E' una classifica a punti che riassume i risultati storici della nostra lega, per trovare un modo di capire, in fondo in fondo, chi &egrave; il pi&ugrave; forte. Per ogni anno ho assegnato dei punti per le varie posizioni occupate al termine del campionato e della coppa: per i campionati, se i partecipanti erano N, il primo ha preso N punti, il secondo N-1, e cos&igrave; via fino all'ultimo che prende un solo punto. Per la coppa, 2 punti al vincitore e 1 punto all'altra finalista. </i></p>
<table border="1" align="center" cellpadding="2" cellspacing="2" class="default">
  <tr>
    <td><div align="left">Squadra</div></td>
    <td  align="right"><div align="center">Punti</div></td>
    <?php
	for ($i=0; $i<count($anni); $i++){
    	echo "<td><div align=\"center\">".$anni[$i][2].$anni[$i][3]."/".$anni[$i][7].$anni[$i][8]."</div></td>";
    }
    ?>
  </tr>
  <?php
  $p=0;
  	while (list($squadra, $punti) = each ($rimet)){
  		$col = $p%2==0?"#D8FEFD":"#FFFFCC";
  		$p++;
  		echo "<tr bgcolor=\"$col\">
	    <td nowrap=\"nowrap\"><div align=\"left\">&nbsp;$squadra&nbsp;</div></td>
	    <td align=\"right\"><div align=\"center\"><strong>&nbsp;$punti&nbsp;</strong></div></td>";
			for ($i=0; $i<count($anni); $i++){
		    	echo "<td><div align=\"center\">&nbsp;{$rimetDetail[$squadra][$anni[$i]]}&nbsp;</div></td>";
		    }
	    echo "</tr>";
	}
  ?>
</table>
<p>&nbsp;</p>
<p class="title">I protagonisti</p>

<?php
while (list($squadra, $andamentoAnno) = each ($rimetDetail)){
	echo "<br/>";
	echo "<p class=\"title\" align=\"left\">$squadra</p>";
	echo "<div align=\"center\">";
	for ($h=0; $h<$scudetti[$squadra]; $h++){
		echo "<img src=\"scudetto.jpg\"/>";
	}
	for ($h=0; $h<$coppe[$squadra]; $h++){
		echo "<img src=\"coppa-italia.jpg\"/>";
	}
	for ($h=0; $h<$retr[$squadra]; $h++){
		echo "<img src=\"b.gif\"/>";
	}
	echo "</div><br/>
      <table width=\"320\" border=\"1\" class=\"default\" bordercolor=\"#000000\">";

		?>
        <tr>
          <td width="40%">
            <div align="center"><b><b></b></b></div>
          </td>
          <td width="30%" bgcolor="#99CC99">
            <div align="center"><b>Campionato</b></div>
          </td>
          <td width="30%" bgcolor="#99CC99">
            <div align="center"><b>Coppa</b></div>
          </td>
        </tr><?php
    while (list($anno, $punti) = each ($andamentoAnno)){
		list($puntCamp, $puntCop) = explode("+",$punti);
		$campionato = count($comp[$anno]['Campionato'])-$puntCamp+1;
		$coppa = $puntCop==""?"-":($puntCop==2?"Vincitore":"Finalista");

		echo "
        <tr>
          <td bgcolor=\"#99CC99\" width=\"40%\">
          <div align=\"center\"><b>$anno</b></div></td>
          <td width=\"30%\">
            <div align=\"center\">$campionato&deg; posto</div>
          </td>
          <td width=\"30%\">
            <div align=\"center\">$coppa</div>
          </td>
        </tr>";
	}
	echo "</table>";
}
?>
<p class="default" align="left">