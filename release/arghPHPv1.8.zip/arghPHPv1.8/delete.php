<?php
  $file1=fopen("news/lastnewswebm",'r+');
  $num2=fgets($file1);
  if ($_GET["id"]==$num2)
  die ("Impossibile cancellare l'ultimo articolo del webmaster.");

if (! unlink("news/".$_GET["id"].".nw"))
die ("Cancellazione non riuscita. La procedura � stata interrotta.");
echo "Cancellazione effettuata con successo. Scalo i numeri d'ordine...";

$file=fopen("news/lastnews",'r+');
$num=fgets($file);rewind($file);	//legge il numero d'ordine dell'ultima news
fwrite($file,$num-1);fclose($file);	//aggiorna il numero d'ordine


  if ($_GET["id"]<$num2 && num2)
  {rewind($file1); fwrite($file1,$num2-1);}
  fclose($file1);

for($i=$_GET["id"]+1;$i<=$num;$i++)
rename("news/".$i.".nw","news/".($i-1).".nw");
echo "Rinominazioni effettuate. <a href=\"javascript:history.back();\">Indietro</a>";

?>

<meta http-equiv="refresh" content="0;URL=index.php">