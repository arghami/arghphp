<?php
session_start();
include("variabili.php");

//definizione funzioni di utilit�
function arrivaa_1($nometeam,$file){	
    while (!feof($file)&&$find==0){
		$rigo=explode("\t",fgets($file));
    if ($rigo[1]==$nometeam) $find=1;
  	}
}
function getPartita($giornatadiA,$squadra){
	$res = "";
	if ($giornatadiA!=null){
		foreach( $giornatadiA as $value){
			if (strpos($value,$squadra) === false){}
			else
				$res = $value;
		}
	}
	return $res;
}

$incontri=estrai_giornate($filecalendario,$nometeam);
if ($incontri[count($incontri)][1]=="") unset($incontri[count($incontri)]);
$t=1;
while ($incontri[$t][1]){
	$giornate_valide[]=$incontri[$t][1];
	$t++;
}
@array_unshift($giornate_valide,"ta");		//mette un elemento in pi� all'inizio per far slittare gli indici
unset($giornate_valide[0]);

//controllo sull'orario. Memorizza la prossima giornata nella var di sessione "gior"

if (!session_is_registered("gior")){
	$file=fopen("SerieA.txt",'r');
	$time=0; $gior=0;
	
	while (!feof($file) && (($time+24*3600)<time() || @!array_search($gior,$giornate_valide)) ){
		$gior++;
		$time=strtotime(fgets($file));
		$term=date("j M Y G:i",$time-$anticipo*60);
	}
	@$ind_gior=array_search($gior,$giornate_valide);
	$_SESSION["gior"]=$gior;
	$_SESSION["term"]=$term;
	$_SESSION["descr"]=$incontri[$ind_gior][2];
	fclose($file);
   
	session_write_close();
}

//carica la giornata di A corrente
$fileserieA=glob("Calendario Serie A*");
if (@ $file=fopen($fileserieA[0],'r')){
	$index=1;
	$tempgior=$_SESSION["gior"];
	if ($_SESSION["gior"]%2==0){	//se � una giornata pari devo andare a leggere il lato destro del file
		$index+=3;
		$tempgior-=1;
	}
	arrivaa_1("Giornata: $tempgior",$file);
	$temp[$index]="ttt";
	while (strlen($temp[$index])>2 && !feof($file)){
		$temp=explode("\t",fgets($file));
		$giornatadiA[]=$temp[$index];
	}
}

$user=$_GET[user];
$pass=$_GET[pass];  //si prende le variabili passate dalla POST del form di login
$valid=0;
$handle=fopen("users/users.us","r");
while(!$valid&&!feof($handle)){			//si interrompe se viene trovato l'user oppure alla fine del file
	$dati=explode("\t",fgets($handle));
	if($dati[0]==$user)
	    $valid=1;
	}
fclose($handle);
if (!$valid)  {		//se l'utente non � stato trovato
	echo "<error>Nome utente o password non validi.</error>";
	die();
}
	else{
	$id=$dati[1];
	$password=$dati[2];
	if (crypt($pass,"key")!=$password)	//se la password non corrisponde
		{
		echo "<error>Nome utente o password non validi.</error>";
		die();
		}
	else
	{
  	if(time()>strtotime($_SESSION["term"])){ //il termine � scaduto
      echo "<error>Spiacente, sei fuori tempo massimo per l'inserimento della formazione.</error>";
      die();
    }
    
    //includo le informazioni per il caricamento delle disponibilit�
	$nomefileassoc=glob("*Risultati*Tutti*");
	$righe = file($nomefileassoc[0]);
	//questo vettore mi permette di associare al nome di un giocatore il suo codice
	$vettAssoc = array();
	for ($i=1; $i<count($righe); $i++){
		$dati = explode("\t",$righe[$i]);
		$vettAssoc[$dati[0]."(".$dati[1].")"] = $dati[3];
	}
	include("downdispo/downdispo.php");
	loadDispo($gior);
	include("downdispo/dispo$gior.php");

    if (@ $file=fopen($filerose,'r')){
    	arrivaa($nometeam[$id],$file);
    	arrivaa("Nome",$file);
    	$i=0; $squadra[2]="a";
    	if ($id)
    		while ($squadra[2]!="") {
    		   $squadra=explode("\t",fgets($file));
    		   
    		   $curdispo = $dispo[$vettAssoc[$squadra[2]."(".$squadra[3].")"]];
	
    		   echo "<r>",substr($squadra[1],0,1),"</r><n>",$squadra[2],"</n><t>",$squadra[3],"</t>".
    		   "<i>",@getPartita($giornatadiA,$squadra[3]),"</i><d>{$curdispo["dispo"]}</d><s>{$curdispo["stato"]}</s><br>";
    		   $i++;
    		}
    	fclose($file);
    }
     }
}
?>