
<div align="center"><img src="regol.jpg"></div>

  