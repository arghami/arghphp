<?php
for($h=1;$h<=count($nometeam);$h++){
	// risistemo le informazioni per calcolarmi i parametri che mi servono
	for($k=1;$k<11;$k++){
		if($dati[$k][$h][0]){
			$parziali[]=$dati[$k][$h][0];
			$totali[]=$dati[$k][$h][1];
			$parziali_avversari[]=$dati[$k][$h][2];
			$totali_avversari[]=$dati[$k][$h][3];
		}
	}
	//calcolo le medie di ogni vettore (e le deviazioni, dove richiesto)
	// non tenendo conto del valore minimo e massimo (per evitare sballamenti)
	unset($parziali[@array_search(min($parziali),$parziali)]);
	unset($parziali[@array_search(max($parziali),$parziali)]);
	unset($totali[@array_search(min($totali),$totali)]);
	unset($totali[@array_search(max($totali),$totali)]);
	list($par,$par_dev)=stats($parziali);
	list($tot,$tot_dev)=stats($totali);
	list($media_tot_avv,)=stats($totali_avversari);
	list($media_parz_avv,)=stats($parziali_avversari);
	
	//preparo i parametri da passare alla funzione probabilita
	$mod=$tot-$parz;
	$dev=($par_dev+$tot_dev)/2;
	$mod_avv=$media_tot_avv-$media_parz_avv;
	
	$info_su_squadra[$nometeam[$h]]=array($par,$dev,$mod,$mod_avv);
	unset($parziali,$totali,$parziali_avversari,$totali_avversari);
}
?>