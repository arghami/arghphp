<?php session_start();

if($_SESSION["user"]=="")
	die("Articolo non inserito: utente non riconosciuto. <a href=\"index.php\">Torna alla homepage</a>");
$file=fopen("news/lastnews",'r+');
$num=fgets($file);rewind($file);	//legge il numero d'ordine dell'ultima news
fwrite($file,$num+1);fclose($file);	//aggiorna il numero d'ordine
if(!$_SESSION["id"]&&$_SESSION["user"]=="webmaster"){		//se l'id dell'user � 0, cio� se � il webmaster
  $tmp=fopen("news/lastnewswebm",'w');
  fwrite($tmp,$num+1);
  fclose($tmp);
  }

$file=fopen("news/".($num+1).".nw",'w');
$titolo=$_POST["titolo"]=="" ? "senza titolo" : $_POST["titolo"];
fwrite($file,$titolo."
".$_SESSION["user"].", ".date ("d.m.Y, G:i", time())."
".strip_tags($_POST["testo"],'<i></i><b></b><a></a>'));

fclose($file);

?>

<meta http-equiv="refresh" content="0;URL=index.php">