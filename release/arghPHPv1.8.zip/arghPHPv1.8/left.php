<br>
<p class="menu"><font color="#000000"> 
  <?php
	$giorno=array("Domenica","Luned�","Marted�","Mercoled�","Gioved�","Venerd�","Sabato");
	$mese=array(1=>"Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre");
	$day=date("w");
	$mon=date("n");
	echo $giorno[$day]." ".date("j")." ".$mese[$mon].", ".date("G:i");
if ($user!="")
echo "<br>Ciao, $user!";
?>
  </font> 
  <?php
echo "<br><br>";

if (empty($_GET[section]))      //se non � stata specificata una sezione, si assume di default la 1 (homepage)
	$current=1;
	else $current=$_GET[section];

if ($user!=""){					//se user non � vuota (� stato fatto il login)
    $limit=count($public)+count($reserved);
    $log="<p class=\"default\">&nbsp";
	if ($_SESSION["id"]==0)
	$log=$log."<a href=\"install.php\">Configurazione</a>";
}
else              // se il login non � stato fatto, viene accorciato il menu e viene preparato il codice del form (che sar� echizzato in fondo)
{
    $limit=count($public);
    $log="</p><form name=\"accesso\" method=\"post\" action=\"autent.php\">
<br>
	<p class=\"menu\"><font color=\"#000000\">Username 
    <input type=\"text\" name=\"user\" size=\"15\">
    <br>
    Password 
    <input type=\"password\" name=\"pass\" size=\"15\"><br><br>
    <input type=\"submit\" name=\"Submit\" value=\"Login\">
	</font>
</form>
";
}

for($i=1;$i<=$limit;$i++)
	if ($i!=$current){			//disabilita e scrive in grigio il link della sezione corrente
	echo "<a href=\"index.php?section=$i\"><img src=\"menuimm/$link[$i]".'a'.".jpg\" border=\"0\"></a><br><br>
";   //$link � definito in index.php
	}
	else
	echo "<img src=\"menuimm/$link[$i]".'b'.".jpg\" border=\"0\"></a><br><br>
";
if ($user!="")
	echo "<a href=\"logout.php\"><img src=\"menuimm/logout.jpg\" border=\"0\"></a><br><br>
";
	echo $log."</p>";  //echizza il link per il logoff o il form per il login, a seconda dei casi
?>
