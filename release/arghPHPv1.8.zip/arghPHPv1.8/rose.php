
<div align="center"><img src="rose.jpg"></div>
<p class="default">Seleziona dal men� a tendina la squadra che ti interessa:</p>
<form name="form1" method=GET action=index.php>
  <input type="hidden" name="section" value="<?php echo array_search("rose",$link); ?>">
  <select name="team">
	<?php
function arrivaa2($stringa_cercata, $stringa_da_evitare, $file){
    $find=false;
    while (!feof($file) && !$find){
	$rigo=explode("\t",fgets($file));
	if ($rigo[1]==$stringa_cercata)
	    $find=true;
	if ($rigo[1]==$stringa_da_evitare)
	    break;
    }
    return $find;
}
	
	$squad=array_search($_GET[team],$nometeam);
	for ($i=1;$i<=$num_squadre;$i++){
	    echo "<option";
		if ($i==$squad)
		echo " selected";
		echo ">$nometeam[$i]</option>
";
}
?>
  </select>

  <input type="submit" value="Ok">
</form>
<table width="550" border="1" cellspacing="0" align="center">
  <tr width="20" class="big"> 
    <td colspan="4">
      <div align="center"><?php echo "$_GET[team]<font class=\"default\"> (presidente $nomeallen[$squad])</font>"; ?></div>
    </td>
  </tr>
  <tr width="20" class="default"> 
    <td><b>Ruolo</b></td>
    <td width="300"><b>Giocatore</b></td>
    <td width="210"><b>Squadra</b></td>
    <td><b>Crediti</b></td>
  </tr>
  <?php

if (@ $file=fopen($filerose,'r')){
	arrivaa($nometeam[$squad],$file);
	arrivaa("Nome",$file);
	$i=1; $squadra[2]="a";
	if ($squad)
		while ($squadra[2]!="") {
		   $squadra=explode("\t",fgets($file));
		   if ($i%2) $color="#FFFFCC"; else $color="#D8FEFD";
		   echo "<tr class=\"default\" bgcolor=\"$color\"><td>",substr($squadra[1],0,1),"</td><td>",$squadra[2],"</td><td>",$squadra[3],"</td><td>",$squadra[5],"</td></tr>
		   ";
		   $i++;
		}
	
	while (substr($squadra[1],0,7)!="Crediti" && $squad && !feof($file))
		$squadra=explode("\t",fgets($file));
		echo "<tr class=\"default\"><td colspan=\"4\">Crediti residui: <b>".substr($squadra[1],17)."</b></td></tr>";
	fclose($file);
}
?>
</table>
<br>
<table width="550" border="1" align="center">
  <tr>
    <td class="default"><b>Giocatori tagliati:</b><br>
<?php    
	if (@ $file=fopen($filerose,'r')){
	    arrivaa($nometeam[$squad],$file);
	    arrivaa("Nome",$file);
	    if(arrivaa2("Giocatori svincolati","Bilancio",$file)){
		fgets($file);
		if ($squad)
		    do {
			$squadra=explode("\t",fgets($file));
			echo "<br>".substr($squadra[1],0,1)." ".$squadra[2];
		    } while ($squadra[2]);
	    }
	    fclose($file);
	}
?>
	</td>
  </tr>
</table>
<p>&nbsp;</p>