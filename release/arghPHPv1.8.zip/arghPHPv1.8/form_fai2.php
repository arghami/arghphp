<?php
//definizione funzioni di utilit�
function arrivaa_1($nometeam,$file){	
    while (!feof($file)&&$find==0){
		$rigo=explode("\t",fgets($file));
    if ($rigo[1]==$nometeam) $find=1;
  	}
}

function plotta_riquadro($giornatadiA,$squadra,$pl){
	if ($giornatadiA!=null){
		echo "
		<div id=\"layer$pl\" style=\"position:absolute; width:120px; height:140px; left:400px; visibility: hidden; z-index: 0;\"> 
			<table width=\"100%\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"#CCFFFF\">
				<tr class=\"mini_yellow\" bgcolor=\"#0000FF\"><td>Serie A: ".$_SESSION["gior"]."� giornata</td></tr>";
		foreach( $giornatadiA as $value){
			if (strpos($value,$squadra) === false)
				echo "<tr><td align=\"center\" class=\"mini\">$value</td></tr>";
			else
				echo "<tr><td align=\"center\" class=\"mini\" bgcolor=\"#FFFF00\">".str_replace($squadra,"<b>$squadra</b>",$value)."</td></tr>";
		}
		echo "</table></div>
		";
	}
}

//carica la giornata di A corrente
$fileserieA=glob("Calendario Serie A*");
if (@ $file=fopen($fileserieA[0],'r')){
	$index=1;
	$tempgior=$_SESSION["gior"];
	if ($_SESSION["gior"]%2==0){	//se � una giornata pari devo andare a leggere il lato destro del file
		$index+=3;
		$tempgior-=1;
	}
	arrivaa_1("Giornata: $tempgior",$file);
	$temp[$index]="ttt";
	while (strlen($temp[$index])>2 && !feof($file)){
		$temp=explode("\t",fgets($file));
		$giornatadiA[]=$temp[$index];
	}
}
//carica la rosa della squadra
if (@ $file=fopen($filerose,'r')){
	arrivaa($nometeam[$id],$file);
	arrivaa("Nome",$file);
	$temp[2]="a";
	$i=0;
	while ($temp[2]!=""){
		$temp=explode("\t",fgets($file));
		$ruolo[$i]=substr($temp[1],0,1);
		$squadra[$i]=$temp[2];
		$squadradiA[$i]=$temp[3];
		$i++;
	}
	fclose($file);
}

else die("Errore nel caricamento delle rose");
$numgioc=count($ruolo);


?>
  </font> 
</p>
<table width="600" border="1" cellpadding="1" cellspacing="0">
  <tr valign="top"> 
    <td width="50%">
      <p><font face="Verdana" size="2">
        <?php

$form=array();

if($pl=="")						// se la stringa � vuota
	if(@ $punt=fopen("users/".$user.".form","r+")){			//se il file esiste
		$form=explode("\t",fgets($punt));
		fclose($punt);
	}
	else $form=array();
	
elseif ($pl>=0 && $pl<100)					//se pl � positivo, inserisci il nuovo giocatore
	if(@ $punt=fopen("users/".$user.".form","r+")){
		$form=explode("\t",fgets($punt)); rewind($punt);		//legge la formazione e torna a inizio file
		$key_vuota=array_search("",$form);
		if ($key_vuota===false)
			$key_vuota=count($form);
		$key_vuota=min($key_vuota,$num_gioc_in_campo-1);

		$form[$key_vuota]=$pl;

		fwrite($punt,implode("\t",$form));
		fclose($punt);
	}
	
	else {											//se il file non esiste (e pl � un num>0), ne forza la creazione
		$punt=fopen("users/".$user.".form","w+");
		fwrite($punt,$pl);
		$form[0]=$pl;
		fclose($punt);
	}
elseif ($pl<0)											//se pl � negativo, cancella il giocatore con id pari a -pl+1 (non posso usare lo zero)
	if(@ $punt=fopen("users/".$user.".form","r+")) {
		$form=explode("\t",fgets($punt));
		ftruncate($punt,0); rewind($punt);
		$form[-$pl-1]="";
		fwrite($punt,implode("\t",$form));
		fclose($punt);
	}
	else $form=array();

elseif ($pl==100)			// rimuove tutti i giocatori dalla formazione
	if (@ $punt=fopen("users/".$user.".form","r+")) {
		ftruncate($punt,0);
		fclose($punt);
	}
	else $form=array();
	

echo "<table width=\"300\" border=\"0\" cellpadding=\"1\" cellspacing=\"0\">
";
echo "<p><b>La tua rosa</b> (clicca su un giocatore per inserirlo in formazione)</b><br><b><a href=\"istruzioni.html\" target=\"_blank\">Istruzioni e consigli (leggere!)</a></b></p>";	

for($i=0;$i<$numgioc;$i++){   //stampa a video la squadra dell'utente
	echo "<tr height=\"10\"> <td width=\"10%\"> <font size=\"2\"> $ruolo[$i] </font></td>";
	
	$curdispo = $dispo[$vettAssoc[$squadra[$i]."(".$squadradiA[$i].")"]];
	
	$dispcolor="";
	if ($curdispo["dispo"]<25){
		$dispcolor="#FF8888";
	}
	else if ($curdispo["dispo"]<75){
		$dispcolor="#FFFF88";
	}
	else {
		$dispcolor="#88FF88";
	}
	
	$status = "";
	if ($curdispo["stato"]==1){
		$status = "<img src=\"inf.png\"/>";
	}
	if ($curdispo["stato"]==2){
		$status = "<img src=\"sq.png\"/>";
	}
	
	echo      "<td width=\"15%\"> <font size=\"2\" style=\"background-color:$dispcolor\">".$curdispo["dispo"]."</font> ".$status." </td>";
	
	
	echo      "<td width=\"75%\"> <font size=\"2\"";
	if (!(array_search((string)$i,$form)===false))
		echo "color=\"#999999\" onMouseOver=\"showHideLayers('layer$i','','show')\" onMouseOut=\"showHideLayers('layer$i','','hide')\"> {$squadra[$i]}</font>";
	else
		echo "> <a href=\"index.php?section=".array_search("form_fai",$link)."&pl=$i#top\" onMouseOver=\"showHideLayers('layer$i','','show')\" onMouseOut=\"showHideLayers('layer$i','','hide')\"> {$squadra[$i]}</a> </font>";
	plotta_riquadro($giornatadiA,$squadradiA[$i],$i);
	echo "</td>";
	
	echo "</tr>
";
}
echo "</table>";


?>
        </font></p>    </td>
    <td><font face="Verdana" size="2"> 
      <?php
echo "<p><b>Giocatori inseriti: </b></p>";
echo "<table width=\"300\" border=\"0\" cellpadding=\"1\" cellspacing=\"0\">
";
	
for($i=0;$i<$num_gioc_in_campo;$i++){   //stampa a video la formazione dell'utente

	echo "<tr> <td width=\"10%\"> <font size=\"2\"> {$ruolo[$form[$i]]} &nbsp; </font></td>";
	echo      "<td width=\"80%\"> <font size=\"2\"> {$squadra[$form[$i]]} &nbsp; </a></font></td>
			   <td width=\"10%\"> <font size=\"2\"> ". ($form[$i]!=""? ("<a href=\"index.php?section=".array_search("form_fai",$link)."&pl=".(-$i-1)."#top\"><img src=\"canc.jpg\" border=\"0\"></img></a>") : "" ) ."&nbsp; </font></td>
";      //sono andato a capo in modo che nel file viene inserito un ritorno a capo
	echo "</tr>";
	if($i==10){
	echo "<tr> <td width=\"10%\">&nbsp;</td>
			   <td width=\"80%\">&nbsp;</td>
			   <td width=\"10%\">&nbsp;</td></tr>
";} 
}
echo "</table>";
echo "<p><a href=\"index.php?section=".array_search("form_fai",$link)."&pl=100#top\">Rimuovi tutto</a> </p>";
?>
      </font></td>
  </tr>
  <tr valign="top"> 
    <td colspan="2" align="left"> 
        <p class="default">Eventuali altre comunicazioni:</p>
        <form method=post action="form_fai_ins.php">
		  <textarea name="altro" cols="50"></textarea>
        </p>
        <p>
          <input type="submit" value="Invia formazione" name="Submit"></form>
      </p></td>
  </tr>
</table>
