<?php
session_start();
if ($_SESSION["user"]!="webmaster")
	die ("Non sei webmaster, non puoi accedere a questa funzione.");
session_start();
$file=fopen("users/users.us",'r');
while (!feof($file) && $info[1]!=$_GET["newid"]){
$info=explode("\t",fgets($file));
}
if ($_GET["newid"]=="0")
	$info[3]=1;
if ($info[3]==0)
die ("L'utente di questa formazione non ti ha dato il permesso di modificare la sua formazione");
$_SESSION["id"]=$_GET["newid"];
echo "id modificato (nuovo id:",$_SESSION["id"],") <a href=\"javascript:history.back();\">Indietro</a>"; ?>