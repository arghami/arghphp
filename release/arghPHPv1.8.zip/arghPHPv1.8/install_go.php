<?php
session_start();
if($_SESSION["user"]!="webmaster") die("Errore. Non sei loggato come webmaster.");

  function arrivaa2($stringa,$file){
    while (!feof($file)&&$find==0){
	$rigo=explode("\t",fgets($file));
    if ($rigo[1]==$stringa) $find=1;
  	}
  }

if ($trovato=glob("Rose*")){
	$filerose=$trovato[0];
	$filecalendario=str_replace("Rose","Calendario",$filerose);
	$fileclassifica=str_replace("Rose","Classifica",$filerose);
	$nomelega=substr($nomefile,5,-4);
	$file=fopen($filerose,'r');
	list(, ,$nometeam[1])=explode("\t",fgets($file));
	$i=2;
	while(!feof($file)){
		arrivaa2("Bilancio",$file);
		arrivaa2("",$file);
		list(, ,$nometeam[$i])=explode("\t",fgets($file));
		if ($nometeam[$i]=="") unset($nometeam[$i]);
		$i++;
	}
}

$fileusers=fopen("users/users.us",'r+');
fgets($fileusers);
for($i=1;$i<=count($nometeam);$i++){
	$pos=ftell($fileusers);		//...si segna la posizione...
	list($user, , ,)=explode("\t",fgets($fileusers));
	if ($_POST["user".$i]!=$user || $_POST["pass".$i]!=""){
		$temp=fread($fileusers,5000);		//...e si memorizza il resto del file
		fseek($fileusers,$pos);			//Torna alla riga dell'utente per riscriverla
		fwrite($fileusers,$_POST["user$i"]."\t".$i."\t".crypt($_POST["pass".$i],"key")."\t0\n");	   
		$pos=ftell($fileusers);
		fwrite($fileusers,$temp);		//dopo aver riscritto la riga, risegna il resto del file che aveva memorizzato in precedenza
		fseek($fileusers,$pos);
	}
}
fclose($fileusers);


if (@$file=fopen("users/users.us",'r')) {
	$utenti[0]=" "; fgets($file);
	while (!feof($file)){
		list($utenti[])=explode("\t",fgets($file));
	}
	fclose($file);
	unset($utenti[0]);
}

$config=fopen("config.php",'w');
fwrite($config,
"<?php
");
if($_POST["link"]!="") 
fwrite($config,"\$linkk=\"".$_POST["link"]."\";
");
if($_POST["email"]!="") 
fwrite($config,"\$email=\"".$_POST["email"]."\";
");

fwrite($config,"\$filerose=\"$filerose\"; \$filecalendario=\"$filecalendario\"; \$fileclassifica=\"$fileclassifica\";
\$nometeam=array(1=> ");
foreach($nometeam as $var)
	fwrite($config, "\"".$var."\", ");
fseek($config,-2,SEEK_CUR);
fwrite($config,");
");
if (count($utenti)){
	fwrite($config,"\$nomeallen=array(1=> ");
	foreach($utenti as $var)
		fwrite($config, "\"".$var."\", ");
	fseek($config,-2,SEEK_CUR);
	fwrite($config,");
");
}


$array_moduli=array("6-3-1","5-4-1","5-3-2","5-2-3","4-5-1","4-4-2","4-3-3","3-5-2","3-4-3");
$scrivimoduli=false;
foreach($array_moduli as $var)
	if ($_POST[$var]=="on")
		$scrivimoduli=true;

if ($scrivimoduli){
	fwrite($config,"\$moduliammessi=array(1=> ");
	foreach($array_moduli as $var)
		if ($_POST[$var]=="on")
			fwrite($config, "\"".$var."\", ");
	fseek($config,-2,SEEK_CUR);
	fwrite ($config,");
");
}
if ($_POST["term"]!="")
	fwrite($config,"\$anticipo=".$_POST["term"].";
");

fwrite($config,"\$backcolor=array(1=> \"#33CCCC\", ".str_repeat("\"#CCFF66\", ",max($_POST["clas"]-1,0)).str_repeat("\"#FFFFFF\", ",max($_POST["clas2"]-$_POST["clas"]-1,0)).str_repeat("\"#FF9966\", ",count($nometeam)-$_POST["clas2"]+1));fseek($config,-2,SEEK_CUR);
fwrite($config,");
");
if ($_POST["clas"]!="" && $_POST["clas2"]!="")
	fwrite($config,"\$clas=".$_POST["clas"]."; \$clas2=".$_POST["clas2"].";
");

for($k=1;$k<=3;$k++)
	if ($_POST["giorno".$k]!="" && $_POST["ora".$k]!="")
		fwrite($config,"\$giornomercato[$k]=".str_replace(array("LUN","MAR","MER","GIO","VEN","SAB"),array(1,2,3,4,5,6),$_POST["giorno".$k])."; \$oramercato[$k]=".$_POST["ora".$k]."; ");
if ($_POST["maxofferte"]!="")
	fwrite($config,"\$maxofferte=".$_POST["maxofferte"].";");

fwrite($config,"
?> ");
fclose($config);


@$filemercato=fopen("mercato.txt",'w');
@$string=file("SerieA.txt");
$start=date("j M Y",strtotime($string[0])+(1-date("w",strtotime($string[0])))*86400);
$stop=date("j M Y",strtotime(array_pop($string))+(1-date("w",strtotime(array_pop($string))))*86400);
$sett=$start;
$j=1;
while (strtotime($sett)< strtotime($stop)){
	if ($_POST["finestra".$j]=="on")
		fwrite($filemercato, $sett."\t");
	$sett=date("j M Y",strtotime($sett)+7*86400+5000);
	if ($_POST["finestra".$j]=="on")
		fwrite($filemercato,$sett."\n");
	$j++;
}


echo "Installazione effettuata con successo. <a href=\"index.php\">Vai alla home</a>";
?>