<?php session_start();
if($_SESSION["user"]!="webmaster") die("Errore. Non sei loggato come webmaster.");
?>
<HTML><title>Skin ArghPHP - Installazione</title>
<link rel="stylesheet" href="style.css" type="text/css">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	background-image: url(install_back.jpg);
}
-->
</style><table class="default" width=600 cellpadding="20" background="install_back.jpg">
  <tr><td><form method="post" action="install_go.php">
<?php

if ($_SESSION["id"]!=0) die("Per effettuare la gestione devi essere loggato come webmaster. <a href=\"javascript:history.back();\">Indietro</a>");
@include("config.php");

  function arrivaa2($stringa,$file){
    while (!feof($file)&&$find==0){
	$rigo=explode("\t",fgets($file));
    if ($rigo[1]==$stringa) $find=1;
  	}
  }

if (@$file=fopen("users/users.us",'r')) {
	$utenti[0]=" "; fgets($file);
	while (!feof($file)){
		list($utenti[])=explode("\t",fgets($file));
	}
	fclose($file);
	unset($utenti[0]);
}

	echo "<p class=\"big\">ArghPHP - installazione</p>";
$installed=file_exists("config.php");
if (!$installed)
	echo "<p class=\"default\">Benvenuto nella prima installazione del sito. Segui la procedura passo-passo per settare correttamente tutte le variabili.</p>";
else
	echo "<p class=\"default\">Benvenuto nella configurazione del sito. Puoi modificare tutte le informazioni stabilite in fase d'installazione. <b>Le modifiche non sono annullabili: se non vuoi perdere la configurazione precedente, salvati i file config.php e users/users.us prima di procedere.</b>";
?>
<p class=default>&nbsp;</p>
<p class=default><b>Passo 1: Informazioni generali </b></p>
<p class=default>
  <input type="text" name="link" <?php if ($installed) echo "value=\"$linkk\""; ?> >
  &lt;- Sito della lega (es: http://legafantacalcio.altervista.org)<br>
  <input type="text" name="email" <?php if ($installed) echo "value=\"$email\"" ?> >
  &lt;- Indirizzo email del webmaster</p>
<p class=default>&nbsp;</p>
<p class=default><b>Passo 2: Definizioni delle squadre e degli utenti</b></p>
<p class=default>Queste sono le squadre rilevate nel file delle rose inserito. Associa ad ogni squadra un username che la gestir&agrave; e la relativa password iniziale (modificabile in seguito). <?php if($installed) echo "<b>La modifica di un campo \"Username\" provocher� la creazione di un nuovo utente per la relativa squadra, con perdita di quello vecchio.</b>";  ?></p>
<?php
if ($trovato=glob("Rose*")){
	$nomefile=$trovato[0];
	$nomelega=substr($nomefile,5,-4);
	$file=fopen($nomefile,'r');
	list(, ,$nometeam[1])=explode("\t",fgets($file));
	$i=2;
	while(!feof($file)){
		arrivaa2("Bilancio",$file);
		arrivaa2("",$file);
		list(, ,$nometeam[$i])=explode("\t",fgets($file));
		if ($nometeam[$i]=="") unset($nometeam[$i]);
		$i++;
	}
	echo "Nome lega: <b>".$nomelega."</b><br><br>";
	echo "<table class=\"default\" border=1><tr><td>Squadra</td><td>Username</td><td>Password</td>";
	for($i=1; $i<=count($nometeam); $i++){
		echo "<tr><td> ".$nometeam[$i]." </td><td><input type=\"text\" name=\"user$i\"";
		if ($installed) echo " value=\"$utenti[$i]\"";
		echo "></td><td><input type=\"text\" name=\"pass$i\"</td></tr>";
	}
	echo "</table>";
}
else echo "Nessun file di rose presente.";
?>

<p>&nbsp;</p>
<p><b>Passo 3: Moduli </b></p>
<p>Seleziona i moduli ammessi nella tua lega:</p>
<p>
  <input name="6-3-1" type="checkbox" <?php if ($installed && @array_search("6-3-1",$moduliammessi)) echo "checked"; ?>> 
  6-3-1<br>
  <input name="5-4-1" type="checkbox" <?php if ($installed && @array_search("5-4-1",$moduliammessi)) echo "checked"; ?>>
  5-4-1<br>
  <input name="5-3-2" type="checkbox" <?php if ($installed && @array_search("5-3-2",$moduliammessi)) echo "checked"; ?>>
  5-3-2<br>
  <input name="5-2-3" type="checkbox" <?php if ($installed && @array_search("5-2-3",$moduliammessi)) echo "checked"; ?>> 
  5-2-3<br>
  <input name="4-5-1" type="checkbox" <?php if ($installed && @array_search("4-5-1",$moduliammessi)) echo "checked"; ?>> 
  4-5-1<br>
  <input name="4-4-2" type="checkbox" <?php if ($installed && @array_search("4-4-2",$moduliammessi)) echo "checked"; ?>>
  4-4-2<br>
  <input name="4-3-3" type="checkbox" <?php if ($installed && @array_search("4-3-3",$moduliammessi)) echo "checked"; ?>> 
  4-3-3<br>
  <input name="3-5-2" type="checkbox" <?php if ($installed && @array_search("3-5-2",$moduliammessi)) echo "checked"; ?>> 
  3-5-2<br>
  <input name="3-4-3" type="checkbox" <?php if ($installed && @array_search("3-4-3",$moduliammessi)) echo "checked"; ?>> 
  3-4-3 </p>
<p>Se utilizzi un modulo non presente tra quelli elencati, aggiungilo manualmente al termine dell'installazione nel file config.php. </p>
<p>&nbsp;</p>
<p><b>Passo 4: Termine invio formazione </b> </p>
<p>
  <input name="term" type="text" size="4" <?php if($installed) echo "value=\"$anticipo\""; ?>>
&lt;- Termine di invio delle formazioni (espresso in minuti di anticipo rispetto alla prima partita della giornata corrente)</p>
<p>&nbsp;</p>
<p><b>Passo 5: Grafica classifica</b></p>
<p>Qui puoi settare la colorazione della classifica, in base alla posizione nella stessa.</p>
<table class="default" border="0" cellspacing="2">
  <tr>
    <td width="17" bgcolor="#33CCCC">&nbsp;</td>
    <td>Primo posto </td>
  </tr>
  <tr>
    <td bgcolor="#CCFF66">&nbsp;</td>
    <td>Zona FFC (dal 2 al 
      <input name="clas" type="text" size="4" <?php if($installed) echo "value=\"$clas\""; ?>> 
      posto incluso)</td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">&nbsp;</td>
    <td>Posti centrali </td>
  </tr>
  <tr>
    <td bgcolor="#FF9966">&nbsp;</td>
    <td>Zona retrocessione (dal 
      <input name="clas2" type="text" size="4"<?php if($installed) echo "value=\"$clas2\""; ?>> 
      posto in gi&ugrave;) </td>
  </tr>
</table>
 <p> Scrivi le posizioni (in numero) nelle caselle vuote. In una lega a 10 squadre, se ad esempio metti 5 e 9, la classifica verr&agrave; colorata cos&igrave;: </p>
 <table class="default" width="120" border="1" cellspacing="0">
   <tr>
     <td bgcolor="#33CCCC">1</td>
   </tr>
   <tr>
     <td bgcolor="#CCFF66">2</td>
   </tr>
   <tr>
     <td bgcolor="#CCFF66">3</td>
   </tr>
   <tr>
     <td bgcolor="#CCFF66">4</td>
   </tr>
   <tr>
     <td bgcolor="#CCFF66">5</td>
   </tr>
   <tr>
     <td bgcolor="#FFFFFF">6</td>
   </tr>
   <tr>
     <td bgcolor="#FFFFFF">7</td>
   </tr>
   <tr>
     <td bgcolor="#FFFFFF">8</td>
   </tr>
   <tr>
     <td bgcolor="#FF9966">9</td>
   </tr>
   <tr>
     <td bgcolor="#FF9966">10</td>
   </tr>
 </table>
 <p>Tieni conto ovviamente del numero delle squadre presenti.</p>
 <p>&nbsp;</p>
 <p><b>Passo 6: Mercato libero</b></p>
 <p>Selezionare le settimane in cui il mercato &egrave; aperto:</p>
<?php
@$string=file("SerieA.txt");
$start=date("j M Y",strtotime($string[0])+(1-date("w",strtotime($string[0])))*86400);
$stop=date("j M Y",strtotime(array_pop($string))+(1-date("w",strtotime(array_pop($string))))*86400);
$sett=$start;
@$stringafinestre="a".file_get_contents("mercato.txt");
$j=1;
while (strtotime($sett)<strtotime($stop)){
	echo "<input type=\"checkbox\" name=\"finestra$j\"";
	if ($stringafinestre=="a" || strpos($stringafinestre, $sett))
		echo " checked";
	echo ">".$sett." - ";
	$sett=date("j M Y",strtotime($sett)+7*86400+5000);
	echo $sett."<br>";
	$j++;
}
 ?>
 <p>&nbsp;</p>
 <p>Selezionare le scadenze settimanali:</p>
 <p>
   <select name="giorno1">
   <?php
   $giorni=array(1=>"LUN","MAR","MER","GIO","VEN","SAB");
	   for ($i=1;$i<=count($giorni);$i++) {
	   echo "<option";
	   if ($giornomercato[1]==$i) echo " selected";
	   echo ">$giorni[$i]</option>";
   }
   ?>
   </select>
ore:
<input name="ora1" type="text" size="5" <?php echo "value=".$oramercato[1]; ?>>
&lt;- Termine per la presentazione delle offerte <br>
<select name="giorno2">
   <?php
	   for ($i=1;$i<=count($giorni);$i++) {
	   echo "<option";
	   if ($giornomercato[2]==$i) echo " selected";
	   echo ">$giorni[$i]</option>";
   }
   ?>
</select>
ore:
<input name="ora2" type="text" size="5" <?php echo "value=".$oramercato[2]; ?>>
&lt;- Termine per la presentazione dell'intenzione di rilanciare<br>
<select name="giorno3">
   <?php
	   for ($i=1;$i<=count($giorni);$i++) {
	   echo "<option";
	   if ($giornomercato[3]==$i) echo " selected";
	   echo ">$giorni[$i]</option>";
   }
   ?>
</select>
ore:
<input name="ora3" type="text" size="5" <?php echo "value=".$oramercato[3]; ?>>
&lt;- Termine per stabilire i crediti del rilancio </p>
 <p>
  <input name="maxofferte" type="text" size="5" <?php echo "value=".$maxofferte; ?>>
&lt;- Numero massimo di offerte presentabili (mettere 0(zero) per non imporre limiti) </p>
 <p>Istruzioni<br>
   Il primo termine va necessariamente specificato, e non &egrave; possibile disabilitarlo.<br>
     Se si omettono secondo e terzo termine si otterr&agrave; una sessione di mercato &quot;al buio&quot;: una volta rese note le offerte, il giocatore va direttamente al miglior offerente.<br>
     Inserendo tutti e tre i termini, si segue alla lettera il regolamento ufficiale (offerte, comunicazione di rilancio, buste).<br>
<b>Nei campi per l'inserimento delle ore, inserire solo ore, non minuti.</b>     </p>
 <p>&nbsp;</p>
 <p align="center">
   <input type="submit" name="Submit" value="Conferma tutto">
 </p>
  </form></td></tr>
</table>