<?php
$autore=news($_GET["id_news"]);
if($_SESSION["user"]=="webmaster")
	echo "<p class=\"default\"><a href=\"delete.php?id=".$_GET["id_news"]."\">elimina articolo</a></p>";
if($_SESSION["user"]!=null){
?>
<p>&nbsp;  </p>
<form name="form1" method="post" action="art_ris_ins.php?id_news=<?php echo $_GET["id_news"] ?>">
  <table width="600" border="0" cellspacing="0" cellpadding="0">
    <tr valign="top">
      <td width="60"><p class=default>Rispondi</p></td>
      <td width="540">
        <textarea name="testo" cols="60" rows="15"></textarea>
      </td>
  </tr>
</table>

  <p>
    <input type="submit" name="Submit" value="Invia risposta">
  </p>
</form>

<?php
}
?>