
<div align="center"></div>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td class="default"> 
	  <p class="title">Archivio offerte</p>
      <p>Visualizza formazioni della settimana:
	  <form name="form1" method=GET action=index.php>
  <input type="hidden" name="section" value="<?php echo array_search("arcoff",$link); ?>">
  <select name="arcgioroff">
	<?php

$file=fopen("mercato.txt",'r');
$weekmercato=0; $i=1;
while  (!feof($file)) {
	$temp=explode("\t",fgets($file));
	if (time()>strtotime($temp[0]) && time()<strtotime($temp[1])) {
		$weekmercato=$i; break;
	}
	$i++;
}
rewind($file);
	for ($i=1;$i<$weekmercato;$i++){
	    echo "<option";
		if ($i==$_GET["arcgioroff"])
		echo " selected";
		echo ">$i</option>
";
}
?>
  </select>

  <input type="submit" value="Ok">
</form>
      <p>
	  <?php
if ($_GET["arcgioroff"]==$weekmercato)
	echo "Non puoi vedere i risultati della settimana attuale di mercato: se la fase 4 � terminata, i risultati sono nella sezione \"formazioni e offerte\".";
elseif ($_GET["arcgioroff"]>$weekmercato)
	echo "Non puoi vedere i risultati di settimane di mercato successive alla $weekmercato.";
else {
	  	scorri($file,$_GET["arcgioroff"]-1);
	  	echo "Risultati offerte settimana <b>".fgets($file)."</b>:<br><br>";
		$giocatore=giocatori_chiamati($_GET["arcgioroff"],$nometeam);
		$giocatore2=risultati_asta($_GET["arcgioroff"],$nometeam);
		echo "<table width=\"90%\" class=\"default\" align=\"center\" cellspacing=\"5\" cellpadding=\"0\"><tr><td width=\"50%\" valign=\"top\">";
		echo "<table width=\"100%\" class=\"default\" border=1 cellspacing=\"0\" cellpadding=\"5\"><b>Chiamate della fase 1:</b><br><br>";
		while (@list($chiave, $valore) = each($giocatore))
    		echo "<tr><td><b>".$chiave."</b><br><br>
			<span class=\"mini\">".$valore."</span><br></td></tr>";
			
		echo "</table></td><td width=\"50%\" valign=\"top\"><table width=\"100%\" class=\"default\" border=1  cellspacing=\"0\" cellpadding=\"5\">";
		echo "<b>Risultati aste</b>:<br><br>";
		while (@list($chiave, $valore) = each($giocatore2))
    		echo "<tr><td><b>".$chiave."</b><br><br>
			<span class=\"mini\">".$valore."</span><br></td></tr>";
		echo "</table></td></tr></table>";
		fclose($file);
}
		?>
		</p>
    </td>
  </tr>
</table>
