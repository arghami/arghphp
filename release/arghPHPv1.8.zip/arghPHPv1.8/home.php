<div align="center">

  <p><img src="home.jpg"></p>

<?php
contatore();

$descr=$_SESSION["descr"];
$term=$_SESSION["term"];
$ingl=array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
echo "<p class=\"default\"><b>Prossima giornata:</b> $descr <br><b>Termine ultimo per l'invio della formazione:</b> ",str_replace($ingl,$mese,$term),"</p>";
?>

  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr valign="top">
      <td width="70%">
<?php
	$export=glob($nomelega."*".".exp");
	if ($export!=null){
		$export_recente=array_pop($export);
		$p1=strrpos($export_recente,"[");
		$p2=strrpos($export_recente,"]");
		$version=substr($export_recente,$p1+1,$p2-$p1-1);
		echo "<p class=\"mini\"><a href=\"$export_recente\"><img src=\"ar_down.gif\" border=\"0\"></a>download export della lega (agg. al ".date ("d.m.Y", filemtime($export_recente)).", FCM $version)</p>
      	<p>";
	}
	if (@$file=fopen("news/lastnewswebm",'r')){
  		$last=fgets($file); fclose($file);
		if ($last>0) newsHome($last);
		if ($_SESSION["user"]!=null) {
			echo "<p class=\"default\"><a href=\"index.php?section=".array_search("legginews",$link)."&id_news=$last\">Rispondi</a></p>";
		}
	}
?>
        </p></td>
      <td>
        <table width="90%" cellspacing="1" cellpadding="1" border="1" align="center" class="mini">
		  <tr>
            <td colspan="2" class="default" background="bar2.jpg"><b>Risultati (<?php echo "<a href=\"risultati.php?giornata=".($_SESSION["gior"]-1)."\">tabellini</a>"; ?>)</b></td></tr>
          <?php
$resultFileName=glob("result/*Risultati".($_SESSION["gior"]-1).".tab");
if(@ $file=fopen($resultFileName[0],"r")){
	while(!feof($file)){
	$array=explode("\t",fgets($file));
	if(array_search($array[2],$nometeam))
	echo "<tr width=\"90%\"><td>$array[2] - $array[8]</td>";
	if($array[4]=="Gol")
	echo "<td><b>$array[5] - $array[11]</b></td></tr>";

	}
	fclose($file);
}
else echo "<tr><td colspan=\"2\">Risultati non ancora disponibili.</td></tr>";

?>
          <tr class="default" valign="top">
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr class="default" valign="top">
            <td colspan="2" background="bar2.jpg"><b>Classifica (<a href=classifica.php target="_blank">dettagli</a>)</b></td>
        </tr>
          <tr valign="top">
            <td width="90%" class="Stile1">Squadra</td>
            <td class="Stile1">Punti</td>
        </tr>

        <?php
if (@$file=fopen($fileclassifica,'r')) {
	scorri($file,3);
	$i=1;
	while(!feof($file)){
		$temp=str_replace(",",".",fgets($file));
		$rigo=explode("\t",$temp);
		if (count($rigo)<2) break;
		echo "<tr bgcolor=$backcolor[$i]>
		<td>$rigo[1]</td>
		<td><font color=\"#000099\" >$rigo[4]</font></td>
		";

		$i++;
	}
}
else echo "<tr><td colspan=\"2\">Classifica non disponibile</td></tr>";
?>
          <tr valign="top">
            <td colspan="2" class="default Stile1">&nbsp;</td>
          </tr>
          <tr valign="top">
            <td colspan="2" background="bar2.jpg" class="default Stile1"><b>Prossimo turno</b> </td>
          </tr>
<?php

$fattore_campo=!strpos($descr,"Neutro");


//estraggo le informazioni per calcolare le quote
for($k=1;$k<9;$k++)
	$dati[$k]=dati_squadra($nometeam, $_SESSION["gior"]-$k);  // raccolgo le informazioni delle ultime 8 girnate

//calcolo i dati per visualizzare le quote
include("dati_quote.php");


for($j=1;$j<=count($gior_att)/2;$j++){
	$t1=2*$j-1; $t2=2*$j;
	if ($nometeam[$gior_att[$t1]]!="" && $nometeam[$gior_att[$t2]]!=""){
		echo "<tr><td colspan=2 class=\"mini\" align=\"center\"><br>".$nometeam[$gior_att[$t1]]." - ".$nometeam[$gior_att[$t2]]."</td></tr>";
		$prob=probabilita( $info_su_squadra[$nometeam[$gior_att[$t1]]] , $info_su_squadra[$nometeam[$gior_att[$t2]]] , $fattore_campo );
		echo "<tr><td colspan=2><table width=\"100%\" border=0 cellpadding=0 cellspacing=0>
		<tr class=\"mini\" align=\"center\"><td width=\"10%\" bgcolor=\"#CCCCCC\"><b>1</b></td>
		<td width=\"23%\" bgcolor=\"#EEEEEE\">". sprintf("%01.2f",1/20*round(16/$prob[0]))."</td>
		<td width=\"10%\" bgcolor=\"#CCCCCC\"><b>X</b></td>
		<td width=\"23%\" bgcolor=\"#EEEEEE\">". sprintf("%01.2f",1/20*round(16/$prob[1]))."</td>
		<td width=\"10%\" bgcolor=\"#CCCCCC\"><b>2</b></td>
		<td width=\"23%\" bgcolor=\"#EEEEEE\">". sprintf("%01.2f",1/20*round(16/$prob[2]))."</td></tr></table></td></tr>";
		}
}

?>

      </table>
    </td>
  </tr>
</table>
  </div>
</HTML>