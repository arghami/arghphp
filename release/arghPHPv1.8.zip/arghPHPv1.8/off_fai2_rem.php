<?php session_start();
include("variabili.php");
echo "<link rel=\"stylesheet\" href=\"style.css\" type=\"text/css\">
<p class=\"default\">
";
if($_SESSION["user"]=="guest")
	die("L'utente \"guest\" non pu� fare offerte. <a href=\"index.php\">Torna alla homepage</a>");

$weekday=date("w");
if (!$weekday) $weekday=7;
$hour=date("G");
for ($fase=1; $fase<4; $fase++)
	if ($oramercato[$fase]=="" || $weekday>$giornomercato[$fase] || ($weekday==$giornomercato[$fase] && $hour>$oramercato[$fase]))
		continue;
	else break;

if ($fase!=2)
	die("E' scaduto il termine per rimuovere l'intenzione di rilancio.");

$weekmercato=$_GET["weekmercato"];

$str=$_POST[menu]."\n";

if (@$offerte=file("users/".$_SESSION["id"]."_ril_".$weekmercato)) {
	$ind=array_search($str,$offerte);
	unset($offerte[$ind]);
}

$file=fopen("users/".$_SESSION["id"]."_ril_".$weekmercato,'w');
foreach($offerte as $value)
	fwrite($file,$value);
fclose($file);

echo "Rilancio rimosso per il giocatore: ".$str."<br>";
echo "<a href=index.php>Torna alla homepage</a>";
?>