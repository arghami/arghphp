<link href="style.css" rel="stylesheet" type="text/css">
<?php

$file=fopen("accessi.txt",'r');

//estrae tutti gli accessi dal file accessi.txt
while (!feof($file)){
	list($dataora)=explode("\t",fgets($file));
	
	if ($dataora!=""){
		list($giorno)=explode(",",$dataora);
		$mese=substr($giorno,3);
		//aggiunge un accesso al contatore di quel giorno (lo crea se non esiste)
		if (isset($accesso[$mese][$giorno]))
			$accesso[$mese][$giorno]++;
		else
			$accesso[$mese][$giorno]=1;
	}
}
fclose($file);

//trova il giorno del massimo
$max_day=0;
while(list($mese,$array)=each($accesso)){
	$accesso_month[$mese]=array_sum($array); //crea un array per i mesi per trovare il mese massimo
	$t=max($array);
	$max_day=max($t,$max_day);
	$keymax=(array_search($max_day,$array)?array_search($max_day,$array):$keymax);
}
$max_month=max($accesso_month);

?>

<p class="big">Statistiche accessi </p>
<table cellpadding="4" cellspacing="0">
<p class="default">Massimo numero di visite registrate in un giorno: <b><?php echo $max_day; ?></b> visite il <?php echo $keymax; ?>.</p>

<?php

//tabella dei mesi
echo "<tr><td valign=\"top\"><table class=\"mini\" border=1 cellspacing=\"0\">";
echo "<tr><td class=\"default\">Statistiche mensili: clicca sul mese per i dettagli.</td></tr>";

$prec=0;
while(list($data,$valore)=each($accesso_month)){
	@$variazione=round(100*($valore-$prec)/$prec);
	echo "<tr><td><a href=\"accessi.php?mese=$data\">".$data."</a> <img src=\"stat/".(round(20*$valore/$max_month)*5).".gif\"> $valore access".($valore=="1"?"o":"i")." (<font color=".($variazione>=0?"\"green\">+":"\"red\">").$variazione."%</font>)</td></tr>";
	$prec=$valore; //si conserva il valore per calcolare la variazione al giro successivo
}

echo "</table></td><td valign=\"top\"><table class=\"mini\" border=1 cellspacing=\"0\">";

//se � stato passato un mese nel GET, apre la tabella dei giorni
if (isset($_GET["mese"])){
	$max_day=max($accesso[$_GET["mese"]]);
	echo "<tr><td align=\"center\">Mese: ".$_GET["mese"]."</td></tr>";
	while(list($data,$valore)=each($accesso[$_GET["mese"]]))
		echo "<tr><td>".$data." <img src=\"stat/".(round(20*$valore/$max_day)*5).".gif\"> $valore access".($valore=="1"?"o":"i")."</td></tr>";
}
echo "</table>";
?>
</table>