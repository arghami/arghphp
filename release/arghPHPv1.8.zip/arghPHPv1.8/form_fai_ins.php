<?php session_start();
echo "<link rel=\"stylesheet\" href=\"style.css\" type=\"text/css\">
<p class=\"default\">
";
if($_SESSION["user"]=="guest")
	die("L'utente \"guest\" non pu� modificare le formazioni. <a href=\"index.php\">Torna alla homepage.</a>");
if(time()>strtotime($_SESSION["term"]))
    die("Spiacente, sei fuori tempo massimo per l'inserimento della formazione. <a href=\"javascript:history.back()\">indietro</a>");

include("variabili.php");

$id=$_SESSION["id"];

if (@ $file=fopen($filerose,'r')){
	arrivaa($nometeam[$id],$file);
	arrivaa("Nome",$file);
	$temp[2]="a";
	$i=0;
	while ($temp[2]!=""){
		$temp=explode("\t",fgets($file));
		$ruolo[$i]=substr($temp[1],0,1);
		$squadra[$i]=$temp[2];
		$i++;
	}
	fclose($file);
}

else die("Errore nel caricamento delle rose");


if($punt=fopen("users/".$_SESSION["user"].".form","r")){			//se il file esiste
	$form=explode("\t",fgets($punt));
	fclose($punt);
}
else $form=array();

$file=fopen("users/".$id."_form_".$_SESSION["gior"].".txt","wb");
for($i=0;$i<count($form);$i++){
	fwrite($file,$ruolo[$form[$i]]." ".$squadra[$form[$i]]);
	fwrite($file,"
");  //scrive un ritorno a capo nel file
	$ruoloschierato[]=$ruolo[$form[$i]];
if ($i==10)
	fwrite($file,"
");  //scrive un ritorno a capo nel file (quello tra titolari e riserve)
}
if($_POST["altro"]!="")
	fwrite($file,"
".$_POST["altro"]);
fclose($file);

$file=fopen("users/".$id."_form_".$_SESSION["gior"].".txt","r");
echo "Formazione correttamente inserita.<br>Questa � la formazione che hai inserito:<br><br>";
while(!feof($file)){
   echo fgets($file),"<br>";
}
fclose($file);

$ruoliusati=array_count_values(array_slice($ruoloschierato,0,11));
$modulo=$ruoliusati["D"]."-".$ruoliusati["C"]."-".$ruoliusati["A"];
if (!array_search($modulo,$moduliammessi)){
	echo "Attenzione, hai schierato la squadra secondo un modulo non ammesso ($modulo). I moduli ammessi sono: ";
	foreach($moduliammessi as $value) echo $value.", ";
}

?>
<br><a href="index.php">Torna alla homepage</a></p>