<script>
window.resizeTo(300, 400);
</script>
<link rel="stylesheet" href="style.css" type="text/css">
<table width="250" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td>

<?php
include("variabili.php");

$incontri=estrai_giornate($filecalendario,$nometeam);
if ($incontri[count($incontri)][1]=="") unset($incontri[count($incontri)]);
$t=1;
while ($incontri[$t][1]){
	$giornate_valide[]=$incontri[$t][1];
	$t++;
}
@array_unshift($giornate_valide,"ta");		//mette un elemento in pi� all'inizio per far slittare gli indici
unset($giornate_valide[0]);

@$ind_gior=array_search($_GET["giornata"],$giornate_valide);
$descr=$incontri[$ind_gior][2];

@$ind_gior=array_search($_GET["giornata"],$giornate_valide);
$ind_start=2;
if (isset($incontri))
while ($incontri[$ind_gior][$ind_start+1]=="" && $ind_start<100){
	$ind_start++;
}
@$gior_att=array_slice($incontri[$ind_gior],$ind_start);
@array_unshift($gior_att,"ta");		//mette un elemento in pi� all'inizio per far slittare gli indici
unset($gior_att[0]);

$fattore_campo=!strpos($descr,"Neutro");


//estraggo le informazioni per calcolare le quote
for($k=1;$k<9;$k++)
	$dati[$k]=dati_squadra($nometeam, $_GET["giornata"]-$k);  // raccolgo le informazioni delle ultime 8 giornate

//calcolo i dati per visualizzare le quote
include("dati_quote.php");
	

for($j=1;$j<=count($gior_att)/2;$j++){
	$t1=2*$j-1; $t2=2*$j;
	if ($nometeam[$gior_att[$t1]]!="" && $nometeam[$gior_att[$t2]]!=""){
		echo "<tr><td colspan=2 class=\"mini\" align=\"center\"><br>".$nometeam[$gior_att[$t1]]." - ".$nometeam[$gior_att[$t2]]."</td></tr>";
		$prob=probabilita( $info_su_squadra[$nometeam[$gior_att[$t1]]] , $info_su_squadra[$nometeam[$gior_att[$t2]]] , $fattore_campo );
		echo "<tr><td colspan=2><table width=\"100%\" border=0 cellpadding=0 cellspacing=0>
		<tr class=\"mini\" align=\"center\"><td width=\"10%\" bgcolor=\"#CCCCCC\"><b>1</b></td>
		<td width=\"23%\" bgcolor=\"#EEEEEE\">". sprintf("%01.2f",1/20*round(16/$prob[0]))."</td>
		<td width=\"10%\" bgcolor=\"#CCCCCC\"><b>X</b></td>
		<td width=\"23%\" bgcolor=\"#EEEEEE\">". sprintf("%01.2f",1/20*round(16/$prob[1]))."</td>
		<td width=\"10%\" bgcolor=\"#CCCCCC\"><b>2</b></td>
		<td width=\"23%\" bgcolor=\"#EEEEEE\">". sprintf("%01.2f",1/20*round(16/$prob[2]))."</td></tr></table></td></tr>";
		}
}
?>

</td>
  </tr>
</table>
