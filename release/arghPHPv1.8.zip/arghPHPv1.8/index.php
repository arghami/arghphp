<?php session_start();

include("variabili.php");
$user=$_SESSION["user"];

$incontri=estrai_giornate($filecalendario,$nometeam);
if ($incontri[count($incontri)][1]=="") unset($incontri[count($incontri)]);
$t=1;
while ($incontri[$t][1]){
	$giornate_valide[]=$incontri[$t][1];
	$t++;
}
@array_unshift($giornate_valide,"ta");		//mette un elemento in pi� all'inizio per far slittare gli indici
unset($giornate_valide[0]);

//controllo sull'orario. Memorizza la prossima giornata nella var di sessione "gior"
if (!session_is_registered("gior")){
	$file=fopen("SerieA.txt",'r');
	$time=0; $gior=0;
	
	while (!feof($file) && (($time+24*3600)<time() || @!array_search($gior,$giornate_valide)) ){
		$gior++;
		$time=strtotime(fgets($file));
		$term=date("j M Y G:i",$time-$anticipo*60);
	}
	@$ind_gior=array_search($gior,$giornate_valide);
	$_SESSION["gior"]=$gior;
	$_SESSION["term"]=$term;
	$_SESSION["descr"]=$incontri[$ind_gior][2];
	fclose($file);
   
	session_write_close();
}

include("define_giornata.php");

  if($user=="" && $section>count($public) && $section<=count($link)-count($other))
  die("Spiacente, non puoi accedere a questa sezione del sito senza login.");
  ?>

<HTML><title><?php echo substr($filerose,5,-4); ?></title>
<link rel="stylesheet" href="style.css" type="text/css">

<script language="JavaScript">
function findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function showHideLayers() { //v3.0
  var i,p,v,obj,args=showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) if ((obj=findObj(args[i]))!=null) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v='hide')?'hidden':v; }
    obj.visibility=v; }
}
</script>

<head>
<?php 

echo
"<SCRIPT LANGUAGE=\"JavaScript1.2\" type=\"text/javascript\">
<!-- // 
var linkk=\"".$linkk."\";
var title=\"".substr($filerose,5,-4)."\";
	function aggiungi(){
		window.external.AddFavorite(linkk,title);
}
//  -->
</SCRIPT>";

?>

</head>
<body vlink="#3366CC" topmargin="0">
<table width="990" align="center" border="1"><tr><td><table width="970" border="0" cellpadding="0" cellspacing="0" align="center">
  <tr align="center"> 
    <td colspan="5" class="default"> 
      <p align="left"><img src="title.jpg" align="middle"><a href="javascript:aggiungi()"><br>
        <img src="menuimm/bar1.jpg" border="0"></a><a href="index.php?section=<?php echo array_search("faq",$link); ?>"><img src="menuimm/bar2.jpg" border="0"></a><a href="mailto:<?php echo $email; ?>"><img src="menuimm/bar3.jpg" border="0"></a>
        <a href="accessi.php"><img src="menuimm/bar4.jpg" width="74" height="21" border="0"></a>
        <?php if($_SESSION["id"]!=0 && $_SESSION["user"]=="webmaster") echo "<a href=\"cambiaid.php?newid=0\">Torna webmaster</a>"; ?><br>
	  </p>    </td>
  </tr>
  <tr valign="top"> 
    <td width="130" background="back1.jpg"> 
      <p> 
        <?php
include("left.php");
?>
      </p>
      
    </td>
	<td width="10">&nbsp; </td>
    <td width="620"> 
      <p><br>
        <?php
include($link[$current].".php");
?>
      </p>
    </td>
	<td width="10">&nbsp; </td>
	<td width="200" background="back2.jpg"> 
      <?php
include("news.php")
?>
    </td> 
  </tr>
<tr class="default">
  <td colspan="5" align="right">Skin creata da Arghami </td>
</tr>
</table>
</td></tr></table>
</body>
</HTML>