<?php
@$file=fopen("users/".$_GET["id"]."_form_".$_GET["gior"].".txt",'w');
fwrite($file, "modificata dal webmaster fuori tempo limite\n\n".$_POST["formazione"]);
fclose($file);
echo "Modifica effettuata. <a href=\"index.php\">Torna alla homepage</a>";
?>