<p class="title">Modifica profilo</p>
<?php

echo "<p class=\"default\">Ciao, $user! Benvenuto nella sezione di gestione del tuo profilo. </p>";
?>

<form method="post" action="profilo_ins.php">
  <p class="default"> 
    <input type="checkbox" name="allow" value="check" <?php
$valid=0;
$handle=fopen("users/users.us","r");

while(!$valid&&!feof($handle)){			//si interrompe se viene trovato l'user oppure alla fine del file
	$dati=explode("\t",fgets($handle));
	if($dati[0]==$user)
	    $valid=1;
	}
fclose($handle);
if($dati[3]!=0)
echo "checked";
?>
>
    <i>Consenti al Webmaster di modificare la tua formazione</i><br>
    (ad esempio se non hai possibilit&agrave; di collegarti spesso a internet 
    e vuoi consegnare la formazione al webmaster, che poi provveder&agrave; a 
    inserirla) </p>
  <p class="default"><i>Cambio password:</i></p>
  <table width="350" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td class="default">Vecchia password </td>
      <td> 
        <input type="text" name="pass">
      </td>
    </tr>
    <tr>
      <td class="default">Nuova password </td>
      <td>
        <input type="password" name="newpass1">
      </td>
    </tr>
    <tr>
      <td class="default">Conferma nuova password</td>
      <td>
        <input type="password" name="newpass2">
      </td>
    </tr>
  </table>
  <p class="default">
    <input type="submit" value="Conferma">
  </p>
  </form>
