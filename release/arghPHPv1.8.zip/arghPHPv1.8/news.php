<p>&nbsp;</p>
<p class="title">Spazio news</p>
<?php

$newsperpagina=7;

$articoli=glob("news/*.nw"); //trova tutti gli articoli presenti
if ($articoli!=null){

	foreach($articoli as $value){
		$articoli_data[filemtime($value)]=str_replace(array("news/",".nw"),array("",""),$value);
	}
	@krsort($articoli_data); //ordina gli articoli per data
	
	if ($_GET["pagina"]!=null){
		$primoarticolo=($_GET["pagina"]-1)*$newsperpagina;
		$paginacorrente=$_GET["pagina"];
	}
	else {
		$primoarticolo=0;
		$paginacorrente=1;
	}
		
	$art_visibili=array_slice($articoli_data,$primoarticolo,$newsperpagina); //isola gli articoli da visualizzare in base ai settaggi.
	$totalepagine=ceil(count($articoli_data)/$newsperpagina);
	
	if ($current==array_search("legginews",$link))
  		$current=1; //torna alla homepage altrimenti si blocca
	
	echo "<p class=\"default\">Vai a pagina: <br>";
	$consec=true; //controlla la scrittura dei puntini
	for ($i=1;$i<=$totalepagine;$i++) {
		if(abs($i-$paginacorrente)<=1 || $i==1 || $i==$totalepagine ){
			if ($consec==false)
				echo " ... , ";
			if ($i==$paginacorrente)
				echo "<b><a href=\"index.php?section=$current&pagina=$i\">$i</a></b>, ";
			else
				echo "<a href=\"index.php?section=$current&pagina=$i\">$i</a>, ";
			$consec=true;
		}
		else $consec=false;
	}
	
	//plotta gli articoli
	foreach($art_visibili as $value){
		anteprima($value,array_search("legginews",$link));
	}
	echo "</p>";
}
/*if (@$file=fopen("news/lastnews",'r')){
  $last=fgets($file); fclose($file);
} else $last=0;
if($_GET["limit_news"]=="")
    $limit=$last;
else
    $limit=max(min($_GET["limit_news"],$last),1);
if ($current==12)
  	$current=1; //torna alla homepage altrimenti si blocca
echo "<p class=\"default_noalign\" align=\"right\">News presenti: $last<br>";
echo "News visualizzate: da ",max($limit+1-$newsperpagina,1)," a $limit<br>";
if ($limit<$last)
     echo "<a href=\"index.php?section=$current&limit_news=",$limit+$newsperpagina,"\">Mostra pi� recenti</a> ";
if ($limit-$newsperpagina>0)
     echo "<br><a href=\"index.php?section=$current&limit_news=",$limit-$newsperpagina,"\">Mostra meno recenti</a> ";
for($i=$limit;$i>max(0,$limit-$newsperpagina);$i--){
	anteprima($i);
	echo "<a href=\"index.php?section=".array_search("legginews",$link)."&id_news=$i\">Leggi articolo</a>";
	if (isset($_SESSION["id"])&&!$_SESSION["id"])
		echo "<br><br><a href=\"delete.php?id=$i\">Elimina articolo</a>";
	echo "</p>";
}*/
?>
