<?php session_start();
if($_SESSION["user"]=="guest")
	die("Il profilo dell'utente \"guest\" non � modificabile. <a href=\"index.php\">Torna alla homepage</a>");
$user=$_SESSION["user"];
$pass=$_POST[pass];

	$handle=fopen("users/users.us","r");
	$valid=0; $riga=0;
	while(!$valid&&!feof($handle)){			//termina quando viene trovato l'utente (dovrebbe trovarlo sempre, l'utente � gi� registrato) o quando finisce il file; restituisce la riga relativa all'user
		$dati=explode("\t",fgets($handle));
		if($dati[0]==$user)
		    $valid=1;
		$riga++;
		}
	fclose($handle);
	$password=$dati[2];
	$stringa=$dati[0]."\t".$dati[1]."\t";		//comincia a preparare la stringa che verr� reinserita nel file
	if (crypt($pass,"key")!=$password){
	   echo "- Modifica password non riuscita: password errata<br>";
	   $stringa=$stringa.$dati[2]."\t";
	   }
	elseif ($_POST[newpass1]!=$_POST[newpass2]){
	   echo "- Modifica password non riuscita: la nuova password non � stata confermata correttamente: torna indietro e assicurati di scrivere la stessa nuova password nelle due caselle in cui ti � richiesta.<br>";
	   $stringa=$stringa.$dati[2]."\t";
	   }
	else{
		$stringa=$stringa.crypt($_POST[newpass1],"key")."\t";
		echo "-Modifica password effettuata<br>";
		}

		if($_POST[allow]!=""){
		  $stringa=$stringa."1\n";
		  echo "- Il webmaster pu� modificare la tua formazione<br>";
		  }
		else{
		  $stringa=$stringa."0\n";
		  echo "- Il webmaster non pu� modificare la tua formazione<br>";
		  }
		  
	   $handle=fopen("users/users.us","r+");
	   for($i=1;$i<$riga;$i++)		//arriva alla riga dell'user...
		fgets($handle);
	   $pos=ftell($handle);			//...si segna la posizione...
	   fgets($handle);			//...salta la riga dell'utente...
	   $temp=fread($handle,5000);		//...e si memorizza il resto del file
	   fseek($handle,$pos);			//Torna alla riga dell'utente per riscriverla
	   fwrite($handle,$stringa);	   
	   fwrite($handle,$temp);		//dopo aver riscritto la riga, risegna il resto del file che aveva memorizzato in precedenza
	   fclose($handle);
	   echo "<a href=javascript:history.back();>Indietro</a>";
?>