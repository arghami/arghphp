
<p class="title">Mercato libero - fase 3 (buste) </p>
<form name=form method=post action="off_fai3_ins.php<?php echo "?weekmercato=$weekmercato"; ?>">
  <table width="100%" border="1" cellpadding="5" cellspacing="0" >
  <tr> 
      <td width="50%" class="default"><p>Nella fase precedente hai deciso di partecipare alle aste che vedi nella lista qui sotto. Specifica il valore del rilancio per ciascuna asta. Devi inserire in busta almeno un credito in pi&ugrave; dell'offerta del <em>chiamante</em> (se sei tu il <em>chiamante</em> puoi ribadire l'offerta iniziale ritirandoti dall'asta).
      </p>
      </td>
  </tr>
  <tr> 
    <td width="50%">  
      <p class="default">&nbsp;</p>      
      <p class="default">Queste sono le aste a cui hai deciso di partecipare. Seleziona il numero di crediti per ciascuna asta.<br>
          <br>
        <table width="95%" border="1" align="center" class="mini">
		<tr>
		<td width="60%">Asta</td>
		<td>cr</td>
		<td>Giocatore da scartare</td>
		</tr>
	  <?php 
$aste=aste($weekmercato,$nometeam);
if (@$file=fopen("users/".$_SESSION["id"]."_ril_".$weekmercato,'r')) {
	$x=0;
	while(!feof($file)){
		$str=explode("\t",fgets($file));
		if ($str[0]!=""){
			$str[0]=str_replace("\n","",$str[0]);
			$taglio_prec="";
			echo "<tr><td width=\"60%\">".$str[0]." <br> partecipanti: ".str_replace("\t",", ",$aste[$str[0]]).
			"</td><td><input type=text name=\"off$x\" size=3 ";
			if ($str[1]!="")
				echo "value=$str[1]";
			echo "></td><td><select name=\"menu$x\">";
			if (@ $file2=fopen($filerose,'r')){
				arrivaa($nometeam[$_SESSION["id"]],$file2);
				arrivaa("Nome",$file2);
				$squadra[2]="a";
				while ($squadra[2]!="") {
					$squadra=explode("\t",fgets($file2));
					echo "<option ";
					
					//cerca il giocatore tagliato nella fase 1
					if ($offerte=file("users/".$_SESSION["id"]."_off_".$weekmercato)) {
						foreach ($offerte as $value){
							$offerta=explode("\t",$value);
							if ($offerta[0]==$str[0] && $offerta[2]==(substr($squadra[1],0,1)." ".$squadra[2])){
								$taglio_prec="<br>Giocatore tagliato nella fase 1: ".$squadra[2];
								break;
							}
						}
					}
					
					// segna come selezionatolo svincolo che gi� compare nel file dei rilanci... 
					if (str_replace("\n","",$str[2])==(substr($squadra[1],0,1)." ".$squadra[2]))
						echo "selected";
					//...oppure quello che � stato indicato nella fase 1
					elseif (!isset($str[2]) && @strpos($taglio_prec, $squadra[2])){
						echo "selected";
					}
					echo ">".substr($squadra[1],0,1)," ",$squadra[2],"</option>
					";
				}
	
				while (substr($crediti,0,7)!="Crediti" && !feof($file2))
					list(,$crediti)=explode("\t",fgets($file2));
				$crediti=substr($crediti,17);
				fclose($file2);
			}
		echo "</select>$taglio_prec</td></tr>";
		}
	$x++;
	}
}
?>
        </table> 
      <p>&nbsp;</p></td>
  </tr>
  <tr> 
    <td>
        <div align="center" class="default_noalign">
          <p>(Hai 
            <?php echo $crediti; ?>
            crediti) <br>
            <input type="submit" name="Submit" value="Conferma offerte">
          </p>
          <p align="left"><i><b>Note:</b></i><br>
            - L'offerta NON VIENE analizzata dal server, &egrave; solo testuale. 
            Quindi se sbagli a fare qualcosa (ad esempio metti in lista infortunati 
            un giocatore che in realt&agrave; sta bene, oppure metti pi&ugrave; 
            crediti di quelli che hai, ecc....)  non verr&agrave; visualizzato nessun messaggio di errore.</p>
        </div>
    </td>
  </tr>
</table>
</form>