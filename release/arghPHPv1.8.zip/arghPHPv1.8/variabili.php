<?php
@include("config.php");
$num_squadre=count($nometeam);
$numgioc=count($ruolo);
$num_gioc_in_campo=18;
$public=array("home","calendario","rose","form_off","regolamento","statistiche","albo");
$reserved=array("form_fai","off_fai","art_fai","profilo");
$other=array("legginews","faq","arcform","modifica","arcoff","accessi");
$link=array_merge($public, $reserved, $other);
@array_unshift($link,"ta");		//mette un elemento in pi� all'inizio per far slittare gli indici
unset($link[0]);

//definizione delle funzioni di news
  function anteprima($id,$sezionelettura){
  $nomefile="news/".$id.".nw";
  $numrisposte=substr_count(file_get_contents($nomefile),"[[reply");  //cerca il numero di risposte in base ai [[reply
  $file=fopen($nomefile,'r');
  echo "<p><table background=\"bar3.jpg\" class=\"art_title\" width=\"100%\">
  <tr><td>";
  if (isset($_SESSION["lastlog"]) && $_SESSION["lastlog"]<filemtime($nomefile))
  	echo "<img src=\"nuovo.gif\"></img>";
  echo "<a href=\"index.php?section=$sezionelettura&id_news=$id\"><b>".str_replace("\\","",fgets($file));
  $autoreedata=fgets($file);
  $autore=explode(",",$autoreedata);
  echo "</b></a> (".$autore[0].", <b>$numrisposte</b> rispost".($numrisposte==1?"a":"e").")<br>
  <span class=\"mini\">ultimo msg: ".date ("d.m.Y, G:i", filemtime($nomefile))."</span></td></tr></table></p>";
  echo "<p class=\"art_text\">";
  echo str_replace(array("\\","[[reply=","]]"),array("","<br>",": "),strip_tags(fread($file,80)))."...";
  echo "<br>";
  fclose($file);
  }

  function scorri($handlefile,$righe){
  for($i=0;$i<$righe;$i++)
  fgets($handlefile);
  }
  
  function arrivaa($nometeam,$file){
    while (!feof($file)&&$find==0){
	$rigo=explode("\t",fgets($file));
    if ($rigo[2]==$nometeam) $find=1;
  	}
  }
  
  function news($id_news){
  $nomefile="news/".$id_news.".nw";
  $file=fopen($nomefile,'r');
  echo "<p><table background=\"bar2.jpg\"  class=\"art_title\"><tr><td><b>\" ".str_replace("\\","",fgets($file))."\"</b> (";
  $autoreedata=fgets($file);
  $autore=explode(",",$autoreedata);
  echo $autoreedata.")</td></tr></table></p>";
  echo "<p class=\"art_text\">";
  while(!feof($file))
  echo str_replace(array("\\","[[reply=","]]"),array("","<br><img src=\"line.gif\"></img><br><table background=\"bar3.jpg\" class=\"art_title\"><tr><td>","</td></tr></table>"),fgets($file))."<br>";
  echo "</p>";
  fclose($file);
  return $autore[0];
  }
  
  function autore($id_news){
  $nomefile="news/".$id_news.".nw";
  $file=fopen($nomefile,'r');
  fgets($file);
  $autoreedata=fgets($file);
  $autore=explode(",",$autoreedata);
  fclose($file);
  return $autore[0];
  }
  
// definizione delle funzioni di statistiche

function marcatori($squadra,$giornata){
$resultFileName=glob("result/*Risultati".$giornata.".tab");
if (@$file=fopen($resultFileName[0],'r')){
	while (!feof($file)&&$find==0){
		$array=explode("\t",fgets($file));
		if ($array[2]==$squadra)
			{$find=1; $index=2;}
		else if ($array[8]==$squadra)
			{$find=1; $index=8;}
	}
	
	if ($find) {
		scorri($file,2);
		for ($i=0;$i<10;$i++){
			$array=explode("\t",fgets($file));
			$player[$i]=$array[$index];
			$fm[$i]=str_replace(",",".",trim($array[$index+3]));
		}
		while ($array[4]!="Gol"){
			$array=explode("\t",fgets($file));
			$goals=trim($array[3+$index]);
		}
		while ($goals>0){
			$m=max($fm);
			$ind=array_search($m,$fm);
			$goleador[]=$player[$ind];
			$fm[$ind]-=3;
			$goals--;
		}
	}
	fclose($file);
	return $goleador;
}
}

function squadre_appartenenza($giocatore,$nometeam,$filerose){
	if (@$file=fopen($filerose,'r'))
		while(!feof($file)){
			$array=explode("\t",fgets($file));
			if(array_search($array[2],$nometeam))
				$tmp=$array[2];
			elseif($array[2]==$giocatore)
				$squadre_gioc[]=$tmp;
		}
	return $giocatore." <i><span class=\"mini\">(".implode( ", ",$squadre_gioc).")</span></i>";
	
}

function contatore(){
	if (@$file=fopen("accessi.txt",'a')){
		fwrite($file,date("d.m.Y, G:i")."\t".$_SERVER[REMOTE_ADDR]."\t".$_SERVER[HTTP_REFERER]."\t".$_SERVER[HTTP_ACCEPT_LANGUAGE]."\t".$_SERVER[HTTP_USER_AGENT]."\n");
		fclose($file);
	}
}

// estrai_giornate: estrae tutte le giornate del calendario della lega e le restituisce
// in un vettore bidimensionale. Ogni riga del vettore restituito corrisponde a una giornata
// ed � fatta cos�:
// gior_di_A    fantag.   nomesq   nomesq .....
function estrai_giornate($nomefile,$nometeam){
	if (@$file=fopen($nomefile,'r')){
		$i=1;
		scorri($file,1);
		while(true){
			$array=explode("\t",fgets($file));
			if ($array[1]=="") break;
			$incontri[$i][1]=substr($array[1],15);      $incontri[$i+1][1]=substr($array[4],15);
			$array=explode("\t",fgets($file));
			$incontri[$i][2]=$array[1];      $incontri[$i+1][2]=$array[4];
			while(true) {
				$array=explode("\t",fgets($file));
				if ($array[1]==" " && $array[4]==" ") break;
				$arraytemp=explode(" - ",$array[1]);
				if (count($arraytemp)!=0){
					$incontri[$i][]=array_search($arraytemp[0],$nometeam);
					$incontri[$i][]=array_search($arraytemp[1],$nometeam);
				}
				$arraytemp=explode(" - ",$array[4]);
				if (count($arraytemp)!=0){
					$incontri[$i+1][]=array_search($arraytemp[0],$nometeam);
					$incontri[$i+1][]=array_search($arraytemp[1],$nometeam);
				}
			}
			$i=$i+2;
		}
	fclose($file);
	return $incontri;
	}
}

function giocatori_chiamati($weekmercato,$nometeam){
	for ($i=1;$i<=count($nometeam);$i++){
		if(@$file=fopen("users/".$i."_off_".$weekmercato,'r')){
			while (!feof($file)){
				$array=explode("\t",fgets($file));
				if ($array[0]!=""){
				$giocatore[$array[0]].=" -".$nometeam[$i]." (".$array[1]." cr, taglia ".$array[2].")<br>";
					if (str_replace("\n","",$array[3])=="si")
						$giocatore[$array[0]].="(L.I.)";
					$giocatore[$array[0]].="\n";
				}
			}
			fclose($file);
		}
	}
	@krsort($giocatore);
	return $giocatore;
}

function aste($weekmercato,$nometeam){
	for ($i=1;$i<=count($nometeam);$i++){
		if(@$file=fopen("users/".$i."_ril_".$weekmercato,'r')){
			while (!feof($file)){
				$array=explode("\t",fgets($file));
				if ($array[0]!=""){
					$array[0]=str_replace("\n","",$array[0]);
					$giocatore[$array[0]].=$nometeam[$i]."<br>";
				}
			}
			fclose($file);
		}
	}
	@krsort($giocatore);
	return $giocatore;
}

function risultati_asta($weekmercato,$nometeam){
	for ($i=1;$i<=count($nometeam);$i++){
		if(@$file=fopen("users/".$i."_ril_".$weekmercato,'r')){
			while (!feof($file)){
				$array=explode("\t",fgets($file));
				if ($array[0]!="")
				$giocatore[$array[0]].=" -".$nometeam[$i]." (".$array[1]." cr, taglia ".substr($array[2],0,-1).")<br>";
			}
			fclose($file);
		}
	}
	@krsort($giocatore);
	return $giocatore;
}


function probabilita ($info_su_squadra1, $info_su_squadra2, $fattore_campo){

// Questa funzione calcola la probabilit� che in una data partita escano i segni 1, x e 2.
// Teoria: i punteggi di ogni squadra vengono assunti come gaussiani. Sommo tra loro i vari
// contributi che danno luogo al totale (presunto) di ogni squadra: poi sommo le due v.a.
// gaussiane, sommando medie e varianze. Poi valuto le probabilit� in base agli intervalli
// ricoperti da questa nuova v.a. [mu-sigma, mu+sigma] rispetto all'intervallo [-3, 3]. Se sto
// all'interno � pareggio, se sto all'esterno vince una delle due squadre.

// $parz1= parziale della squadra
// $dev1= media tra la deviazione standard del parziale e quella del totale
// $mod1= differenza tra parziale e totale
// $mod_avv1= differenza tra parziale e totale AVVERSARIO

list($parz1, $dev1, $mod1, $mod_avv1)=$info_su_squadra1;
list($parz2, $dev2, $mod2, $mod_avv2)=$info_su_squadra2;

	if (!$parz1 || !$dev1)
		return array(1/3,1/3,1/3);

	if ($fattore_campo)
		$parz1+=3;  // chi gioca in casa parte da +3
	
	$tot1=$parz1+$mod1+$mod_avv2;
	$tot2=$parz2+$mod2+$mod_avv1;
	
	//calcola media e deviazione standard della variabile somma
	$tot=($tot1-$tot2)/3;
	$dev=sqrt( pow($dev1,2) + pow($dev2,2) );
	//confronta gli intervalli [-delta,delta] e [tot-dev, tot+dev], calcola le ampiezze delle zone in cui
	//la variabile va oltre il +delta (vittoria in casa), o sotto il -delta (vittoria in trasferta) oppure �
	// in [+delta,-delta] (pareggio): quest'ultimo non � detto che sia 2delta, ad es se tot+dev non arriva a delta!
	// In questo caso uno dei tre eventi verrebbe a probabilit� zero, per evitarlo faccio in modo che
	// questa ampiezza non sia pi� piccola di 2.
	$correzione_delta=min((($tot1+$tot2)/2-66)/5,2);   // fattore correttivo per rendere pi� probabile il pareggio a basse medie
														//al variare della media del totale tra [66,76] il correttore varia tra [0,2]
	$delta=4 - $correzione_delta;
	$amp_vittoria_casa = max(($tot+$dev)-$delta, 2);
	$amp_vittoria_trasferta = max(-($tot-$dev)-$delta , 2);
	$amp_pareggio = max( min ($delta , $tot+$dev) - max($tot-$dev , -$delta) , 2);
	
	$amp_totale=$amp_vittoria_casa + $amp_vittoria_trasferta + $amp_pareggio;
	
	$vittoria_casa = $amp_vittoria_casa/$amp_totale;
	$pareggio = $amp_pareggio/$amp_totale;
	$vittoria_trasferta = $amp_vittoria_trasferta/$amp_totale;
	
	return array($vittoria_casa, $pareggio, $vittoria_trasferta);
}


function dati_squadra($nometeam, $id_giornata) {
	// La funzione restituisce una matrice: su ogni riga ci sono i dati di una squadra
	// calcolati per quella singola giornata. Questi sono i dati estratti:
	// [parz_squadra   tot_squadra   parz_avv   tot_avv   tot_centrocampo   mod_centrocampo]
	$resultFileName=glob("result/*Risultati".$id_giornata.".tab");
	if (@$file=fopen($resultFileName[0],'r')){
		
		for ($i=1;$i<=count($nometeam);$i++)  //inizializza a zero la colonna dei totali centrocampo
			$dati[$i][4]=0;
		
		while(!feof($file)){
		
			$array=explode("\t",str_replace(",",".",fgets($file)));  // legge una riga e sostituisce le virgole con punti
			
			// se trova i nomi delle squadre, si segna gli ID per scrivere nella giusta riga del vettore
			if(array_search($array[2],$nometeam)){
				$ind1=array_search($array[2],$nometeam);
				$ind2=array_search($array[8],$nometeam);
			}
			
			// se c'� la scritta parziale squadra, si segna il parziale di entrambe le squadre,
			// e lo segna anche come parziale avversario nell'altra squadra
			if($array[4]=="Parziale squadra"){
				$dati[$ind1][0]=$dati[$ind2][2]=$array[5];
				$dati[$ind2][0]=$dati[$ind1][2]=$array[11];
			}
			// se la riga contiene un centrocampista, aggiorna il totale di centrocampo della squadra (separatamente per le due ssquadre)
			if($array[1]=="C")
				$dati[$ind1][4]+=$array[3];
			if($array[7]=="C")
				$dati[$ind2][4]+=$array[9];
			
			// se c'� la scritta totale squadra, si segna il totale di entrambe le squadre,
			// e lo segna anche come totale avversario nell'altra squadra
			if($array[4]=="Totale squadra"){
				$dati[$ind1][1]=$dati[$ind2][3]=$array[5];
				$dati[$ind2][1]=$dati[$ind1][3]=$array[11];
			}
			
			// se c'� la scritta Modificatore centrocampo...
			if($array[4]=="Modificatore centrocampo"){
				$dati[$ind1][5]=$array[5];
				$dati[$ind2][5]=$array[11];
			}
			
		}
		fclose($file);
		return $dati;
	}
}

function stats($array) {
//restituisce media e varianza di un vettore di elementi
	//media
	if ($array){
		$parameters[0]=array_sum($array)/count($array);
		foreach( $array as $value)
			$array_diff[]=pow($value-$parameters[0],2);
		//varianza
		$parameters[1]=sqrt(array_sum($array_diff)/count($array_diff));
		return $parameters;
	}
}

?>