<div align="center"><img src="form.jpg"></div>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td class="default"> 
      <p>&nbsp;</p>
      <p><b><i>Formazioni 
        <?php echo $_SESSION["descr"] ?>
        <br>
        </i></b>(per formazioni precedenti consulta l'<a href="index.php?section=<?php echo array_search("arcform",$link); ?>&arcgior=1">archivio 
        formazioni</a>) </p>
      <p> 
        <?php

if(time()<strtotime($_SESSION["term"]))
    echo "Non � ancora scaduto il termine per l'invio delle formazioni.</p><p>";
    echo "<table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"5\">";

    for($i=1;$i<=count($gior_att);$i++){
    if ($gior_att[$i]=="") continue;
	if ($i % 2) echo "<tr class=\"default\">";
    echo "<td width=\"50%\">";
	echo "<p><b>",$nometeam[$gior_att[$i]],"</b><br>";

	$j=0; $find=0;
	while ($j<4 && ($_SESSION["gior"]-$j)>0 && !$find){
	    $filen="users/".$gior_att[$i]."_form_".($_SESSION["gior"]-$j).".txt";
	    if (@ $formaz=fopen($filen,'r')) $find=1;
	    $j++;
	}
	if (!$find) echo "Nessuna formazione inviata nelle ultime $j giornate";
    else{
	echo "(formazione inviata il ",date ("d.m.Y, G:i", filemtime($filen)),")";
	if ($j>1) echo "(precedente)";
	echo "<br><br>";
	    if(time()>strtotime($_SESSION["term"])||$_SESSION["id"]==$gior_att[$i])
		while (!feof($formaz))
	    echo fgets($formaz),"<br>";
    	    fclose($formaz);
	}
    echo "</p>";
    echo "</td>
";
    if (! ($i % 2)) echo "</tr>";
    }
echo "</table>";

?>
      </p>
    </td>
  </tr>
  <tr>
    <td class=default>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p><b><i>Mercato<br>
      </i></b>(per offerte precedenti consulta l'<a href="index.php?section=<?php echo array_search("arcoff",$link); ?>&arcgioroff=1">archivio offerte</a>)</p>
      <p>
        <?php

$weekday=date("w");
if (!$weekday) $weekday=7;
$hour=date("G");
for ($fase=1; $fase<4; $fase++) {
	if (!isset($oramercato[$fase]) || $weekday>$giornomercato[$fase] || ($weekday==$giornomercato[$fase] && $hour>=$oramercato[$fase]))
		continue;
	else break;
}
$file=fopen("mercato.txt",'r');
$weekmercato=0; $i=1;
while  (!feof($file)) {
	$temp=explode("\t",fgets($file));
	if (time()>strtotime($temp[0]) && time()<strtotime($temp[1])) {
		$weekmercato=$i; break;
	}
	$i++;
}

$nomefase=array(1=>"Presentazione offerte","Comunicazione rilanci","Consegna buste","Risultati buste");
echo "Fase attuale: fase $fase - ".$nomefase[$fase],"<br><br>";
switch($fase) {
case 1 : 
		break;
case 2 :
		echo "Offerte presentate nella fase 1:<br><br>";
		$giocatore=giocatori_chiamati($weekmercato,$nometeam);
		echo "<table width=\"100%\" class=\"default\" border=1 cellspacing=\"0\" cellpadding=\"5\">";
		while (@list($chiave, $valore) = each($giocatore))
    		echo "<tr><td><b>".$chiave."</b><br><br>
			<span class=\"mini\">".$valore."</span><br></td></tr>";
		echo "</table>";
		break;
case 3 :
		echo "Aste in corso:<br>";
		$giocatore=aste($weekmercato,$nometeam);
		echo "<table width=\"100%\" class=\"default\" border=1 cellspacing=\"0\" cellpadding=\"5\">";
		while (@list($chiave, $valore) = each($giocatore))
    		echo "<tr><td><b>".$chiave."</b><br><br>
			<span class=\"mini\">".$valore."</span><br></td></tr>";
		echo "</table>";
		break;
case 4 :
		$giocatore=giocatori_chiamati($weekmercato,$nometeam);
		$giocatore2=risultati_asta($weekmercato,$nometeam);
		echo "<table width=\"90%\" class=\"default\" align=\"center\" cellspacing=\"5\" cellpadding=\"0\"><tr><td width=\"50%\" valign=\"top\">";
		echo "<table width=\"100%\" class=\"default\" border=1 cellspacing=\"0\" cellpadding=\"5\"><b>Chiamate della fase 1:</b><br><br>";
		while (@list($chiave, $valore) = each($giocatore))
    		echo "<tr><td><b>".$chiave."</b><br><br>
			<span class=\"mini\">".$valore."</span><br></td></tr>";
			
		echo "</table></td><td width=\"50%\" valign=\"top\"><table width=\"100%\" class=\"default\" border=1  cellspacing=\"0\" cellpadding=\"5\">";
		echo "<b>Risultati aste</b>:<br><br>";
		while (@list($chiave, $valore) = each($giocatore2))
    		echo "<tr><td><b>".$chiave."</b><br><br>
			<span class=\"mini\">".$valore."</span><br></td></tr>";
		echo "</table></td></tr></table>";
		break;
}
?>

      </p>
      <p>&nbsp;</p>
    </td>
  </tr>
</table>
